package parsing

import (
	"fmt"
	"io"
	"strconv"
	"strings"

	"github.com/alecthomas/participle"
	"github.com/alecthomas/participle/lexer"
	"github.com/alecthomas/participle/lexer/regex"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
)

type Constraints struct {
	Constraints []Constraint `parser:"@@*"`
}

type Constraint struct {
	Name  string   `parser:"@Name"`
	Parms []string `parser:"(LeftSqPar (@Int (Comma @Int)*)? RightSqPar)?"`
	Args  []string `parser:"LeftPar (@(NameWS|Name) (Comma @(NameWS|Name))*)? RightPar"`
}

var lexerC = lexer.Must(regex.New(`
	NameWS = [\p{L}_][-\p{L}\d_]*( +[-\p{L}\d_]+)+
	Name = [\p{L}_][-\p{L}\d_]*
	Int = \d+
	LeftPar = \(
	RightPar = \)
	LeftSqPar = \[
	RightSqPar = \]
	Comma = ,
	space = \s
`))

var constraintsParser = participle.MustBuild(
	&Constraints{}, participle.Lexer(lexerC),
)

func (constr Constraint) GetName() string {
	return constr.Name
}

func (constr Constraint) GetArgs() []string {
	return constr.Args
}

func (constr Constraint) GetParams() []int {
	params := make([]int, 0, len(constr.Parms))
	for _, p := range constr.Parms {
		pi, err := strconv.Atoi(p)
		if err != nil {
			logging.Fatal().Str("value", p).AnErr("Atoi", err).Msg("Converting value to integer, this shouldn't happen here.")
			pi = 0
		}
		params = append(params, pi)
	}
	return params
}

func (constr Constraint) String() string {
	return fmt.Sprintf("%s[%s](%s)", constr.Name, strings.Join(constr.Parms, ","), strings.Join(constr.Args, ","))
}

func ParseConstraints(in io.Reader) ([]Constraint, error) {
	cl := &Constraints{}
	err := constraintsParser.Parse(in, cl)
	if err != nil {
		return nil, err
	}
	return cl.Constraints, nil
}

func Lex(in io.Reader) ([]lexer.Token, error) {
	return constraintsParser.Lex(in)
}
