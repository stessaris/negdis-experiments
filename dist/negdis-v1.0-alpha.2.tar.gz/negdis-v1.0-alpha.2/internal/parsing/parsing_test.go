package parsing_test

import (
	"fmt"
	"strings"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/parsing"
)

func ExampleParseConstraints() {
	inS := `
	Response( Notify cancellation, 
		Cancel application )
	AlternateResponse( Cancel application,Notify cancellation)
	AlternateResponse(Notify cancellation , Cancelapplication )
	Init(Action 1)
	Absence[2](Notify cancellation)
	`
	cl, err := parsing.ParseConstraints(strings.NewReader(inS))
	if err != nil {
		panic(fmt.Errorf("Error reading constraints: %v", err))
	}
	for _, c := range cl {
		fmt.Println(c)
	}
	//Output:
	// Response[](Notify cancellation,Cancel application)
	// AlternateResponse[](Cancel application,Notify cancellation)
	// AlternateResponse[](Notify cancellation,Cancelapplication)
	// Init[](Action 1)
	// Absence[2](Notify cancellation)
}

func ExampleLex() {
	inS := `
	Response(Notify cancellation, 
		Cancel application )
	AlternateResponse(Cancel application,Notify cancellation)
	AlternateResponse(Notify cancellation,Cancel application)
	Init(Action 1)
	Absence[2](Notify cancellation)
	`
	tokens, err := parsing.Lex(strings.NewReader(inS))
	if err != nil {
		panic(fmt.Errorf("Error lexing: %v", err))
	}
	for _, t := range tokens {
		fmt.Printf("%#v\n", t)
	}
	//Output:

}
