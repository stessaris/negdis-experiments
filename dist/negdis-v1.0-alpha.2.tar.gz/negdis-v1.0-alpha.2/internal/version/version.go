package version

// Versioning information: `git describe --always --dirty`
// to be set using:
//   -ldflags "-X 'gitlab.inf.unibz.it/wrkflw/negdis/internal/version.GitVersion=$(git describe --always --dirty)'"
var GitVersion = ""
