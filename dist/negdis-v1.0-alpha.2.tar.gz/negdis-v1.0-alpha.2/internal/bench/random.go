package bench

import (
	"io"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/discover"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints/declare"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

func RandomLog(out io.Writer, activities int, size int, meanTrace int, devTrace int) error {
	lastAct := wrkfls.Activity(activities)
	log := traces.RandomLog(size, lastAct, meanTrace, devTrace)
	patterns := declare.PatternBase().Patterns()

	err := discover.ProfileAllSAT(out, log, patterns)
	return err
}
