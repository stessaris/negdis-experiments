package combinations

import (
	"context"
	"fmt"
	"log"
	"sort"
)

func Combinations(ctx context.Context, max_value, arity int) <-chan []int {
	if arity > max_value {
		log.Printf("The arity (%d) cannot be bigger than the last integer (%d)\n", arity, max_value)
	}
	ch := make(chan []int)

	go func() {
		defer close(ch)

		if arity <= max_value {
			result := make([]int, arity)
			for i, _ := range result {
				result[i] = i
			}
			select {
			case <-ctx.Done():
				return
			case ch <- append([]int(nil), result...):
			}
			for {
				for i := arity - 1; i >= 0; i-- {
					if result[i] < i+max_value-arity {
						result[i]++
						for j := 1; j < arity-i; j++ {
							result[i+j] = result[i] + j
						}
						select {
						case <-ctx.Done():
							return
						case ch <- append([]int(nil), result...):
						}
						break
					}
				}
				if result[0] >= max_value-arity {
					break
				}
			}
		}
	}()

	return ch
}

func CombinationsInt(ctx context.Context, elements []int, arity int) <-chan []int {
	ch := make(chan []int)

	// make sure they're sorted
	iterable := append([]int(nil), elements...)
	sort.Ints(iterable)

	go func() {
		defer close(ch)
		length := len(iterable)
		for comb := range Combinations(ctx, length, arity) {
			result := make([]int, arity)
			for i, val := range comb {
				result[i] = iterable[val]
			}
			select {
			case <-ctx.Done():
				return
			case ch <- result:
			}
		}
	}()
	return ch
}

func SubsetsInt(ctx context.Context, elements []int, counters OrdCounters) <-chan []int {
	ch := make(chan []int)
	// make sure they're sorted
	iterable := append([]int(nil), elements...)
	sort.Ints(iterable)
	go func() {
		defer close(ch)
		for i := 1; i < len(iterable); i++ {
			for comb := range CombinationsInt(ctx, iterable, i) {
				if counters != nil {
					if !counters.Eq(comb) {
						continue
					}
					if err := counters.Inc(len(comb)); err != nil {
					}
				}
				select {
				case <-ctx.Done():
					return
				case ch <- comb:
				}
			}
		}
		select {
		case <-ctx.Done():
			return
		case ch <- iterable:
		}
	}()
	return ch
}

type OrdCounters interface {
	Inc(size int) error
	Eq(seq []int) bool
}

type intCounters struct {
	maxValue int
	counters [][]int
}

func NewCounter(size, max_value, start int) OrdCounters {
	counters := intCounters{
		maxValue: max_value,
		counters: make([][]int, size),
	}
	for j := range counters.counters {
		counters.counters[j] = make([]int, j+1)
		for i := 0; i < j+1; i++ {
			counters.counters[j][i] = start + i
		}
	}
	return counters
}

func (counter intCounters) Inc(size int) error {
	workCounter := counter.counters[size-1]
	for i := len(workCounter) - 1; i >= 0; i-- {
		if workCounter[i] < counter.maxValue-len(workCounter)+i {
			workCounter[i]++
			for j := i + 1; j < len(workCounter); j++ {
				workCounter[j] = workCounter[j-1] + 1
			}
			return nil
		}
	}
	// move counter out of the valid range
	startVal := counter.maxValue - len(workCounter) + 1
	for i := range workCounter {
		workCounter[i] = startVal + i
	}
	return fmt.Errorf("Cannot increase %v", workCounter)
}

func (counter intCounters) Eq(ordSeq []int) bool {
	if len(counter.counters) < len(ordSeq) {
		return false
	}
	for i, v := range counter.counters[len(ordSeq)-1] {
		if v != ordSeq[i] {
			return false
		}
	}
	return true
}

func AllSequences(ctx context.Context, items []int, arity int) <-chan []int {
	ch := make(chan []int)
	max_idx := len(items)

	nextIdx := func(idx []int) {
		for j := len(idx) - 1; j >= 0; j-- {
			idx[j]++
			if j == 0 || idx[j] < max_idx {
				return
			}
			idx[j] = 0
		}
	}

	All := func(hot []bool) bool {
		for _, v := range hot {
			if !v {
				return false
			}
		}
		return true
	}

	go func() {
		defer close(ch)
		result := make([]int, arity)
		present := make([]bool, max_idx)
		for ix := make([]int, arity); ix[0] < max_idx; nextIdx(ix) {
			for i := range present {
				present[i] = false
			}
			for i, j := range ix {
				present[j] = true
				result[i] = items[j]
			}
			if All(present) {
				select {
				case <-ctx.Done():
					return
				case ch <- append([]int(nil), result...):
				}
			}
		}
	}()

	return ch
}

// Permutations generates all the permutations of the (different) integers in input
//
// Implement the Heap's algorithm described in https://en.wikipedia.org/wiki/Heap%27s_algorithm
func Permutations(ctx context.Context, items []int) <-chan []int {
	ch := make(chan []int)

	go func() {
		defer close(ch)

		c := make([]int, len(items))
		for i := range c {
			c[i] = 0
		}

		result := append(make([]int, 0, len(items)), items...)

		select {
		case <-ctx.Done():
			return
		case ch <- append(make([]int, 0, len(result)), result...):
		}

		for i := 0; i < len(result); {
			if c[i] < i {
				if 0 == (i % 2) { // even
					result[0], result[i] = result[i], result[0]
				} else {
					result[c[i]], result[i] = result[i], result[c[i]]
				}
				select {
				case <-ctx.Done():
					return
				case ch <- append(make([]int, 0, len(result)), result...):
				}
				c[i]++
				i = 0
			} else {
				c[i] = 0
				i++
			}
		}

	}()

	return ch
}
