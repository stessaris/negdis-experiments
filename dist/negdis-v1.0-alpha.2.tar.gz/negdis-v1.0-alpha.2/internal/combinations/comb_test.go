package combinations_test

import (
	"context"
	"fmt"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/combinations"
)

func ExampleSubsetsInt() {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	for sSet := range combinations.SubsetsInt(ctx, []int{2, 3, 4}, nil) {
		fmt.Println(sSet)
	}

	// Output:
	// [2]
	// [3]
	// [4]
	// [2 3]
	// [2 4]
	// [3 4]
	// [2 3 4]
}

func ExampleSubsetsByComb() {
	max_value := 5
	max_arity := 3

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	counter := combinations.NewCounter(max_arity, max_value, 0)
	for comb := range combinations.Combinations(ctx, max_value, max_arity) {
		fmt.Print(comb, " ->")
		for sSet := range combinations.SubsetsInt(ctx, comb, counter) {
			fmt.Print(" ", sSet)
		}
		fmt.Println()
	}

	// Output:
	// [0 1 2] -> [0] [1] [2] [0 1] [0 2] [0 1 2]
	// [0 1 3] -> [3] [0 3] [0 1 3]
	// [0 1 4] -> [4] [0 4] [0 1 4]
	// [0 2 3] -> [0 2 3]
	// [0 2 4] -> [0 2 4]
	// [0 3 4] -> [0 3 4]
	// [1 2 3] -> [1 2] [1 3] [1 2 3]
	// [1 2 4] -> [1 4] [1 2 4]
	// [1 3 4] -> [1 3 4]
	// [2 3 4] -> [2 3] [2 4] [3 4] [2 3 4]
}

func ExampleSeqByComb() {
	max_value := 5
	max_arity := 3
	seq_arity := 2

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	counter := combinations.NewCounter(max_arity, max_value, 0)
	for comb := range combinations.Combinations(ctx, max_value, max_arity) {
		fmt.Print(comb, " ->")
		for seq := range combinations.AllSequences(ctx, comb, seq_arity) {
			fmt.Print(" ", seq)
		}
		for sSet := range combinations.SubsetsInt(ctx, comb, counter) {
			for seq := range combinations.AllSequences(ctx, sSet, seq_arity) {
				fmt.Print(" ", seq)
			}
		}
		fmt.Println()
	}

	// Output:
	// [0 1 2] -> [0 0] [1 1] [2 2] [0 1] [1 0] [0 2] [2 0]
	// [0 1 3] -> [3 3] [0 3] [3 0]
	// [0 1 4] -> [4 4] [0 4] [4 0]
	// [0 2 3] ->
	// [0 2 4] ->
	// [0 3 4] ->
	// [1 2 3] -> [1 2] [2 1] [1 3] [3 1]
	// [1 2 4] -> [1 4] [4 1]
	// [1 3 4] ->
	// [2 3 4] -> [2 3] [3 2] [2 4] [4 2] [3 4] [4 3]
}

func ExamplePermutations() {

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	items := []int{1, 4, 3}

	for perm := range combinations.Permutations(ctx, items) {
		fmt.Println(perm)
	}

	// Output:
	// [1 4 3]
	// [4 1 3]
	// [3 1 4]
	// [1 3 4]
	// [4 3 1]
	// [3 4 1]
}
