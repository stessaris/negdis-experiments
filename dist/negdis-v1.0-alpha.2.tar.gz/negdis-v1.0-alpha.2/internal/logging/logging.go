package logging

import (
	"io"
	"sort"

	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func init() {
	zerolog.SetGlobalLevel(zerolog.WarnLevel)
}

func SetOutput(out io.Writer) {
	log.Logger = log.Output(out)
}

func ActivateDebug() {
	log.Logger = log.With().Caller().Logger()
	zerolog.SetGlobalLevel(zerolog.DebugLevel)
}

func IsDebug() bool {
	return ActiveLevel(zerolog.DebugLevel)
}

func ActiveLevel(level zerolog.Level) bool {
	return zerolog.GlobalLevel() <= level
}

func Debug() *zerolog.Event {
	return log.Debug()
}

func Warn() *zerolog.Event {
	return log.Warn()
}

func Fatal() *zerolog.Event {
	return log.Fatal()
}

type traceLogger struct {
	trace []wrkfls.Activity
}

func (tLogger traceLogger) MarshalZerologArray(a *zerolog.Array) {
	for _, act := range tLogger.trace {
		a.Int(int(act))
	}
}

func TraceLogger(trace []wrkfls.Activity) *traceLogger {
	return &traceLogger{trace}
}

type mappingLogger struct {
	wrkfls.ActivityNames
}

func ActivityMapLogger(mapping wrkfls.ActivityNames) *mappingLogger {
	return &mappingLogger{mapping}
}

func (mLogger mappingLogger) MarshalZerologObject(e *zerolog.Event) {
	names := mLogger.Names()
	keys := append(names[:0:0], names...)
	sort.Strings(keys)
	for _, k := range keys {
		if a, ok := mLogger.Get(k); ok {
			e.Int(k, int(a))
		}
	}
}
