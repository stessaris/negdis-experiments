package discover

import (
	"context"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/combinations"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/ctraces"
)

func Compatibles(ctx context.Context, posLog wrkfls.Log, patterns []wrkfls.Pattern) <-chan wrkfls.Constraint {
	ch := make(chan wrkfls.Constraint)

	maxArity := maxConstraintArity(patterns)

	lastAct := lastActivity(posLog)

	go func() {
		defer close(ch)

		counter := combinations.NewCounter(maxArity, int(lastAct), 0)
		for comb := range combinations.Combinations(ctx, int(lastAct), maxArity) {
			cLog := ctraces.CompressLog(posLog, intToActivities(comb)...)

			for sSet := range combinations.SubsetsInt(ctx, comb, counter) {
				for c := range compatibleWithSet(ctx, sSet, cLog, patterns) {
					select {
					case <-ctx.Done():
						return
					case ch <- c:
					}
				}
			}
		}
	}()

	return ch
}

func Choices(posLog, negLog wrkfls.Log, patterns []wrkfls.Pattern) ([][]wrkfls.Constraint, error) {
	ctx, cancel := context.WithCancel(context.TODO())
	defer cancel()

	choices := make([][]wrkfls.Constraint, negLog.Size())

	maxArity := maxConstraintArity(patterns)
	lastAct := lastActivity(posLog, negLog)

	counter := combinations.NewCounter(maxArity, int(lastAct), 0)
	for comb := range combinations.Combinations(ctx, int(lastAct), maxArity) {
		combAct := intToActivities(comb)

		cPLog := ctraces.CompressLog(posLog, combAct...)
		cNLog := ctraces.CompressLog(negLog, combAct...)

		for sSet := range combinations.SubsetsInt(ctx, comb, counter) {
			for c := range compatibleWithSet(ctx, sSet, cPLog, patterns) {
				sat, err := cNLog.Check(c)
				if err != nil {
					return nil, err
				}
				for i, b := range sat {
					if !b {
						choices[i] = append(choices[i], c)
					}
				}
			}
		}
	}

	return choices, nil
}

func compatibleWithSet(ctx context.Context, indexes []int, posLog wrkfls.CompressedLog, patterns []wrkfls.Pattern) <-chan wrkfls.Constraint {
	ch := make(chan wrkfls.Constraint)

	go func() {
		defer close(ch)

		for seq := range combinations.Permutations(ctx, indexes) {
			activities := intToActivities(seq)
			for _, pattern := range patterns {
				// skip patterns with parameters or arity different from arguments
				if pattern.ParamArity() > 0 || pattern.Arity() != len(activities) {
					continue
				}
				c, err := pattern.NewConstraint(activities, []int{})
				if err != nil {
					logging.Warn().AnErr("error", err).Msg("failed to create the constraint")
					continue
				}
				if sat, err := posLog.Satisfies(c); err != nil || !sat {
					if err != nil {
						logging.Warn().AnErr("error", err).Msg("failed to check logs")
					}
					continue
				}

				select {
				case <-ctx.Done():
					return
				case ch <- c:
				}
			}
		}
	}()

	return ch
}

func intToActivities(seq []int) []wrkfls.Activity {
	actSeq := make([]wrkfls.Activity, len(seq))
	for i, v := range seq {
		// first activity is always 1, combinations start from 0
		actSeq[i] = wrkfls.Activity(v) + 1
	}
	return actSeq
}

func maxConstraintArity(patterns []wrkfls.Pattern) int {
	maxArity := 1
	for _, p := range patterns {
		if p.Arity() > maxArity {
			maxArity = p.Arity()
		}
	}
	return maxArity
}
