package discover

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"sort"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func WriteCompatibleConstraints(out io.Writer, log wrkfls.Log, patternsBase wrkfls.PatternDict, activityMap wrkfls.ActivityNames) error {
	ctx, cancel := context.WithCancel(context.TODO())
	defer cancel()

	result := make([]string, 0)
	for c := range Compatibles(ctx, log, patternsBase.Patterns()) {
		result = append(result, c.ToString(activityMap))
	}
	sort.Strings(result)
	for _, s := range result {
		fmt.Fprintln(out, s)
	}

	return nil
}

func WriteUnsatChoices(out io.Writer, pLog wrkfls.Log, nLog wrkfls.Log,
	patternsBase wrkfls.PatternDict, activityMap wrkfls.ActivityNames) error {

	choices, err := Choices(pLog, nLog, patternsBase.Patterns())
	if err != nil {
		return err
	}

	jsonEnc := json.NewEncoder(out)
	if _, err := io.WriteString(out, "[\n"); err != nil {
		return err
	}
	defer func() {
		if _, err := io.WriteString(out, "]\n"); err != nil {
			logging.Debug().Msg("Cannot write on file")
		}
	}()
	sep := ""
	for i, constraints := range choices {
		if _, err := io.WriteString(out, sep); err != nil {
			return err
		}
		sep = ",\n"
		trace, err := nLog.Trace(i)
		if err != nil {
			logging.Fatal().AnErr("error", err).Int("index", i).Int("size", nLog.Size())
			return err
		}
		if err := jsonEnc.Encode(map[string][]string{
			"trace":   traceToStrings(trace, activityMap),
			"choices": constraintsToStrings(constraints, activityMap)}); err != nil {
			return err
		}
	}
	return nil
}

func CheckConstraints(out io.Writer, log wrkfls.Log, constraints []wrkfls.Constraint, activityMap wrkfls.ActivityNames) error {
	if logging.IsDebug() {
		logging.Debug().Object("activitymap", logging.ActivityMapLogger(activityMap)).Msg("activity names")
	}
	jsonEnc := json.NewEncoder(out)
	if _, err := io.WriteString(out, "[\n"); err != nil {
		return err
	}
	defer func() {
		if _, err := io.WriteString(out, "]\n"); err != nil {
			logging.Debug().Msg("Cannot write on file")
		}
	}()
	satMatrix := make([][]bool, log.Size())
	for i := range satMatrix {
		satMatrix[i] = make([]bool, len(constraints))
	}
	for i, c := range constraints {
		sat, err := log.Check(c)
		if err != nil {
			return err
		}
		for j, b := range sat {
			satMatrix[j][i] = b
		}
	}
	sep := ""
	cStrings := constraintsToStrings(constraints, activityMap)
	satStat := map[string]bool{}
	for i := range satMatrix {
		for j, b := range satMatrix[i] {
			satStat[cStrings[j]] = b
		}
		if _, err := io.WriteString(out, sep); err != nil {
			return err
		}
		sep = ",\n"
		trace, err := log.Trace(i)
		if err != nil {
			logging.Fatal().AnErr("error", err).Int("index", i).Int("size", log.Size())
			return err
		}
		if err := jsonEnc.Encode(map[string]interface{}{
			"trace": traceToStrings(trace, activityMap),
			"sat":   satStat}); err != nil {
			return err
		}
	}
	return nil
}

func traceToStrings(trace []wrkfls.Activity, activityMap wrkfls.ActivityNames) []string {
	mTrace := make([]string, 0, len(trace))

	for _, a := range trace {
		if an, ok := activityMap.GetName(a); !ok {
			mTrace = append(mTrace, fmt.Sprint(a))
		} else {
			mTrace = append(mTrace, an)
		}
	}

	return mTrace
}

func constraintsToStrings(constraints []wrkfls.Constraint, activityMap wrkfls.ActivityNames) []string {
	mConstrs := make([]string, 0, len(constraints))
	for _, c := range constraints {
		mConstrs = append(mConstrs, c.ToString(activityMap))
	}
	return mConstrs
}
