package discover_test

import (
	"context"
	"fmt"
	"os"
	"reflect"
	"sort"
	"strings"
	"testing"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/discover"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints/declare"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

var allDeclPatterns string

func init() {
	allDeclPatterns = declPtrn()
}

func declPtrn(names ...string) string {
	pDict := declare.PatternBase()
	var ptrns string
	if len(names) < 1 {
		for _, p := range pDict.Patterns() {
			ptrns += fmt.Sprint(p) + "\n"
		}
	} else {
		for _, n := range names {
			if p, ok := pDict.GetPattern(n); ok {
				ptrns += fmt.Sprint(p) + "\n"
			}
		}
	}
	return ptrns
}

func checkPatternCompressed(pattern string, params []int, args []rune, logText string) (sat bool, invSat bool, err error) {
	pDict := constraints.NewPatternDict()
	err = constraints.ReadTextPatterns(strings.NewReader(pattern), pDict)
	if err != nil {
		return
	}

	aDict := traces.NewActivityNames()
	var log wrkfls.Log
	log, err = traces.ReadLog(strings.NewReader(logText), "text", aDict)
	if err != nil {
		return
	}
	// make sure args are among valid activities
	actArgs := make([]wrkfls.Activity, 0, len(args))
	for _, a := range args {
		actArgs = append(actArgs, aDict.Add(string(a)))
	}

	// Create compressed log
	cLog := log.Compress(actArgs...)

	var c wrkfls.Constraint
	c, err = pDict.Patterns()[0].NewConstraint(actArgs, params)
	if err != nil {
		return
	}

	sat, err = cLog.Satisfies(c)
	if err != nil {
		return
	}
	if len(args) == 2 {
		invSat, err = cLog.SatisfiesInverse(c)
		if err != nil {
			return
		}
	}

	return
}

func verifyDiscoverComp(patterns string, logText string) (notSat []string, err error) {
	pDict := constraints.NewPatternDict()
	err = constraints.ReadTextPatterns(strings.NewReader(patterns), pDict)
	if err != nil {
		return
	}

	aDict := traces.NewActivityNames()
	var log wrkfls.Log
	log, err = traces.ReadLog(strings.NewReader(logText), "text", aDict)
	if err != nil {
		return
	}

	var constraints []wrkfls.Constraint
	constraints, err = discover.CollectAllSATConstraints(log, pDict.Patterns(), wrkfls.Activity(aDict.Size()))
	if err != nil {
		return
	}

	fmt.Fprintln(os.Stderr, constraints)

	for _, c := range constraints {
		var sat bool
		fmt.Fprintln(os.Stderr, c)
		sat, err = log.Satisfies(c)
		if err != nil {
			return
		}
		if !sat {
			notSat = append(notSat, c.ToString(aDict))
		}
	}
	return
}

func ExampleAllSATConstraints() {
	patternsText := strings.NewReader(`
		RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*
		Response(a, b):[^a]*(a.*b)*[^a]*
		Init(a):a.*
		End(a):.*a
		`)
	logText := strings.NewReader(`
		bcaaccbbbaba
		bcaaccbbbab
		`)

	patternsBase := constraints.NewPatternDict()
	err := constraints.ReadTextPatterns(patternsText, patternsBase)
	if err != nil {
		panic(err)
	}

	activitiesMap := traces.NewActivityNames()
	log, err := traces.ReadLog(logText, "text", activitiesMap)
	if err != nil {
		panic(err)
	}

	ctx, cancel := context.WithCancel(context.TODO())
	defer cancel()

	result := make([]string, 0)
	for c := range discover.Compatibles(ctx, log, patternsBase.Patterns()) {
		result = append(result, c.ToString(activitiesMap))
	}
	sort.Strings(result)
	for _, s := range result {
		fmt.Println(s)
	}

	// Output:
	// Init(b)
	// RespondedExistence(a,a)
	// RespondedExistence(a,b)
	// RespondedExistence(a,c)
	// RespondedExistence(b,a)
	// RespondedExistence(b,b)
	// RespondedExistence(b,c)
	// RespondedExistence(c,a)
	// RespondedExistence(c,b)
	// RespondedExistence(c,c)
	// Response(a,a)
	// Response(b,b)
	// Response(c,a)
	// Response(c,b)
	// Response(c,c)
}

func Test_checkPatternCompressed(t *testing.T) {
	type args struct {
		pattern string
		params  []int
		args    []rune
		logText string
	}
	tests := []struct {
		name       string
		args       args
		wantSat    bool
		wantInvSat bool
		wantErr    bool
	}{
		{"cpc_1", args{`Response(a, b):[^a]*(a.*b)*[^a]*`, nil, []rune{'x', 'y'}, `xzzywwww`}, true, false, false},
		{"cpc_2", args{`Response(a, b):[^a]*(a.*b)*[^a]*`, nil, []rune{'y', 'x'}, `xzzywwww`}, false, true, false},
		{"cpc_3", args{`RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*`, nil, []rune{'x', 'y'}, `ywxxwwyyyxyx`}, true, true, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSat, gotInvSat, err := checkPatternCompressed(tt.args.pattern, tt.args.params, tt.args.args, tt.args.logText)
			if (err != nil) != tt.wantErr {
				t.Errorf("checkPatternCompressed() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSat != tt.wantSat {
				t.Errorf("checkPatternCompressed() gotSat = %v, want %v", gotSat, tt.wantSat)
			}
			if gotInvSat != tt.wantInvSat {
				t.Errorf("checkPatternCompressed() gotInvSat = %v, want %v", gotInvSat, tt.wantInvSat)
			}
		})
	}
}

func Test_verifyDiscoverComp(t *testing.T) {
	type args struct {
		patterns string
		logText  string
	}
	tests := []struct {
		name       string
		args       args
		wantNotSat []string
		wantErr    bool
	}{
		{`dt_1`, args{`
			RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*
			Response(a, b):[^a]*(a.*b)*[^a]*
			Init(a):a.*
			End(a):.*a
			`, `
			bcaaccbbbaba
			bcaaccbbbab
			`,
		}, nil, false},
		{`dt_2`, args{allDeclPatterns, `
			xy
			xzy
			`,
		}, nil, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotNotSat, err := verifyDiscoverComp(tt.args.patterns, tt.args.logText)
			if (err != nil) != tt.wantErr {
				t.Errorf("verifyDiscoverComp() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotNotSat, tt.wantNotSat) {
				t.Errorf("verifyDiscoverComp() = %v, want %v", gotNotSat, tt.wantNotSat)
			}
		})
	}
}
