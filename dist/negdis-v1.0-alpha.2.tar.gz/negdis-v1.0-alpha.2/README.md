# negdis

Tool for extraction and verification of Declare constraints w.r.t. a event log. Code and documentation are available on the [Gitlab project page](https://gitlab.inf.unibz.it/wrkflw/negdis/-/tree/master).

## Install

The tool consists of the single executable `negdis` and can be downloaded from the [project releases](https://gitlab.inf.unibz.it/wrkflw/negdis/-/releases) page, or installed using the [Go](https://golang.org/cmd/go/#hdr-Add_dependencies_to_current_module_and_install_them) compiler:

``` bash
go get -u gitlab.inf.unibz.it/wrkflw/negdis/cmd/negdis
```

If you get an error accessing the GitLab server make sure you can [clone with HTTPS](https://gitlab.inf.unibz.it/help/gitlab-basics/start-using-git.md#user-content-clone-a-repository), or change git defaults as explained [here](https://stackoverflow.com/a/27501039). TL;DR add the following to your [gitconfig file](https://git-scm.com/docs/git-config):

``` ini
[url "git@gitlab.inf.unibz.it:"]
    insteadOf = https://gitlab.inf.unibz.it/
```

## Documentation

Full documentation on the [project wiki](https://gitlab.inf.unibz.it/wrkflw/negdis/-/wikis/home).

### Usage

Use the `help` command to get the description of options and usage:

``` bash
$ negdis help
Negative traces model discovery

Usage:
  negdis [command]

Available Commands:
  bench       Run model discovery benchmarks
  check       Check constraints and traces satisfiability
  discover    Workflow discover algorithms
  help        Help about any command
  show        Display information about internal data
  version     print the version information of the application

Flags:
      --debug            set debug mode
  -h, --help             help for negdis
      --logfile string   write logging to file
      --out string       write output to file path instead of stdout (default "-")

Use "negdis [command] --help" for more information about a command.
```

### Constraints verification

To verify the satisfiability of a set of constraints w.r.t. a set of traces use the `check constraints` command:

``` bash
$ negdis check constraints --fmt xes Logs/negativeLoanApplication_scenario1.xes positiveLoanApplication_scenario1_compatible.txt
[
{"sat":{"AlternatePrecedence(Appraise property,Approve application)":true,"AlternatePrecedence(Appraise property,Ask for customer feedback)":true,…,"AlternatePrecedence(Approve application,Appraise property)":false,…},"trace":["Receive loan application","Appraise property","Check income sources","Assess loan risk","Assess eligibility","Send acceptance pack","Verify receipt","Cancel application","Notify cancellation","Ask for customer feedback","Receive positive feedback"]}
,
…
]
```

### Discovering constraints

To get the list of constraints compatible with a given log use the `discover compatible` command:

``` bash
$ negdis discover compatible example.xes
Init(Event 1)
AtMostOne(Event 1)
Participation(Event 1)
RespondedExistence(Event 1,Event 2)
RespondedExistence(Event 2,Event 1)
…
```

To get the choices of constraints compatible with a positive log that invalidate each of the given negative traces use the `discover negative` command:

``` bash
$ negdis discover negative example.xes negative.xes
[
{"choices":["Init(Event 1)","Participation(Event 1)","RespondedExistence(Event 2,Event 1)","Precedence(Event 1,Event 2)","Succession(Event 1,Event 2)","Succession(Event 2,Event 1)","AlternatePrecedence(Event 1,Event 2)","AlternateSuccession(Event 1,Event 2)","AlternateSuccession(Event 2,Event 1)","AlternateResponse(Event 2,Event 1)","Response(Event 2,Event 1)","CoExistence(Event 1,Event 2)","CoExistence(Event 2,Event 1)","ChainPrecedence(Event 1,Event 3)","Precedence(Event 1,Event 3)","AlternatePrecedence(Event 1,Event 3)","NotChainSuccession(Event 3,Event 2)","NotSuccession(Event 3,Event 2)"],"trace":["Event 3","Event 2"]}
,
{"choices":["Init(Event 1)","Participation(Event 1)","RespondedExistence(Event 2,Event 1)","Precedence(Event 1,Event 2)","Succession(Event 1,Event 2)","Succession(Event 2,Event 1)","AlternatePrecedence(Event 1,Event 2)","AlternateSuccession(Event 1,Event 2)","AlternateSuccession(Event 2,Event 1)","AlternateResponse(Event 2,Event 1)","Response(Event 2,Event 1)","CoExistence(Event 1,Event 2)","CoExistence(Event 2,Event 1)","ChainPrecedence(Event 1,Event 3)","Precedence(Event 1,Event 3)","AlternatePrecedence(Event 1,Event 3)","NotChainSuccession(Event 3,Event 2)","NotSuccession(Event 3,Event 2)"],"trace":["Event 3","Event 3","Event 2"]}
]
```

## Changes

- 2020-05-02: version 0.4.0
  - fixed inverse pattern checking bug. The compatible discovery algorithm of the previous version didn't work properly.
