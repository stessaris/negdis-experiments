package wrkfls

import "regexp"

type Activity int

type Trace []Activity

type CompressedLog interface {
	Constrainable
}

type Log interface {
	Constrainable
	Compress(activities ...Activity) CompressedLog
	Size() int
	Trace(index int) ([]Activity, error)
	Iterator() LogScanner
}

type LogScanner interface {
	Next() bool
	Trace() []Activity
}

type ActivityNames interface {
	Names() []string
	Size() int
	Add(name string) Activity
	Get(name string) (Activity, bool)
	GetName(act Activity) (string, bool)
}

type Constraint interface {
	SCheck(cTrace string) (bool, error)
	SInvCheck(cTrace string) (bool, error)
	Check(trace []Activity) (bool, error)
	InvCheck(trace []Activity) (bool, error)
	Pattern() Pattern
	Args() []Activity
	Parameters() []int
	ToString(mapping ActivityNames) string
}

type Pattern interface {
	Name() string
	Arity() int
	ParamArity() int
	Regex(args []rune, params []int) (*regexp.Regexp, error)
	NewConstraint(args []Activity, params []int) (Constraint, error)
}

type PatternDict interface {
	NewPattern(name string, regex string, args []rune, params []string) (Pattern, error)
	GetPattern(name string) (Pattern, bool)
	Names() []string
	Patterns() []Pattern
}

type Constrainable interface {
	Satisfies(c Constraint) (bool, error)
	SatisfiesInverse(c Constraint) (bool, error)
	Check(c Constraint) ([]bool, error)
}
