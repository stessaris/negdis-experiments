package constraints

import (
	"io"
	"reflect"
	"strings"
	"testing"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func TestReadPatterns(t *testing.T) {
	type args struct {
		in           io.Reader
		patternsBase wrkfls.PatternDict
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "ReadPatterns_1",
			args: args{
				in: strings.NewReader(`
				[
				{
					"Name": "End",
					"Regex": ".*a",
					"Args": [ "a" ],
					"Params": []
				},
				{
					"Name": "RespondedExistence",
					"Regex": "[^a]*((a.*b)|(b.*a))*[^a]*",
					"Args": [ "a", "b" ],
					"Params": []
				}
				]
				`),
				patternsBase: NewPatternDict(),
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if err := ReadJSONPatterns(tt.args.in, tt.args.patternsBase); (err != nil) != tt.wantErr {
				t.Errorf("ReadPatterns() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func Test_parsePatternDef(t *testing.T) {
	type args struct {
		def string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		want1   string
		want2   []rune
		want3   []string
		wantErr bool
	}{
		{
			name: "def_1", args: args{` esp [ m, rr ] ( a,b ) : b\s a{m,rr}.*`},
			want: `esp`, want1: `b\s a{m,rr}.*`, want2: []rune{'a', 'b'}, want3: []string{`m`, `rr`}, wantErr: false,
		},
		{
			name: "Uniqueness", args: args{`Uniqueness(a):[^a]*(a)?[^a]*`},
			want: `Uniqueness`, want1: `[^a]*(a)?[^a]*`, want2: []rune{'a'}, want3: nil, wantErr: false,
		},
		{
			name: "RespondedExistence", args: args{`RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*`},
			want: `RespondedExistence`, want1: `[^a]*((a.*b)|(b.*a))*[^a]*`, want2: []rune{'a', 'b'}, want3: nil, wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, got2, got3, err := parsePatternDef(tt.args.def)
			if (err != nil) != tt.wantErr {
				t.Errorf("parsePatternDef() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("parsePatternDef() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("parsePatternDef() got1 = %v, want %v", got1, tt.want1)
			}
			if !reflect.DeepEqual(got2, tt.want2) {
				t.Errorf("parsePatternDef() got2 = %v, want %v", got2, tt.want2)
			}
			if !reflect.DeepEqual(got3, tt.want3) {
				t.Errorf("parsePatternDef() got3 = %#v, want %#v", got3, tt.want3)
			}
		})
	}
}
