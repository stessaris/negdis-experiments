package constraints

import (
	"fmt"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type constraint struct {
	pattern *constraintPattern
	args    []wrkfls.Activity
	params  []int
}

func (constr constraint) Args() []wrkfls.Activity {
	return constr.args
}

func (constr constraint) Pattern() wrkfls.Pattern {
	return constr.pattern
}

func (constr constraint) Parameters() []int {
	return constr.params
}

func (constr constraint) Check(trace []wrkfls.Activity) (bool, error) {
	mapping := ActivityMap(constr.Args()...)
	sTrace := string(CompressTrace(trace, mapping))

	if logging.IsDebug() {
		logging.Debug().Str("constraint", constr.String()).Array("trace", logging.TraceLogger(trace)).Msg("matching trace")
	}

	return constr.SCheck(sTrace)
}

func (constr constraint) SCheck(cTrace string) (bool, error) {
	return constr.pattern.sCheck(cTrace, constr.params...)
}

func (constr constraint) InvCheck(trace []wrkfls.Activity) (bool, error) {
	mapping := ActivityMap(constr.Args()...)
	sTrace := string(CompressTrace(trace, mapping))

	return constr.SInvCheck(sTrace)
}

func (constr constraint) SInvCheck(cTrace string) (bool, error) {
	return constr.pattern.sInvCheck(cTrace, constr.params...)
}

func (constr constraint) ToString(mapping wrkfls.ActivityNames) string {
	s := constr.pattern.name
	if len(constr.params) > 0 {
		s += "["
		for i, p := range constr.params {
			if i > 0 {
				s += ","
			}
			s += fmt.Sprint(p)
		}
		s += "]"
	}
	s += "("
	for i, a := range constr.args {
		if i > 0 {
			s += ","
		}
		if mapping != nil {
			if an, ok := mapping.GetName(a); ok {
				s += an
			} else {
				s += fmt.Sprint(a)
			}
		} else {
			s += fmt.Sprint(a)
		}
	}
	s += ")"

	return s
}

func (constr constraint) String() string {
	return constr.ToString(nil)
}
