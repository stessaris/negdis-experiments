package constraints

import (
	"sync"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type patternDict struct {
	patterns map[string]*constraintPattern
	mu       sync.RWMutex
}

func (dict *patternDict) keys() []string {
	dict.mu.RLock()
	defer dict.mu.RUnlock()
	names := make([]string, 0, len(dict.patterns))
	for k := range dict.patterns {
		names = append(names, k)
	}
	return names
}

func (dict *patternDict) values() []*constraintPattern {
	dict.mu.RLock()
	defer dict.mu.RUnlock()
	patterns := make([]*constraintPattern, 0, len(dict.patterns))
	for _, v := range dict.patterns {
		patterns = append(patterns, v)
	}
	return patterns
}

func (dict *patternDict) add(cp *constraintPattern) {
	dict.mu.Lock()
	defer dict.mu.Unlock()
	dict.patterns[cp.name] = cp
}

func (dict *patternDict) get(name string) (*constraintPattern, bool) {
	dict.mu.RLock()
	defer dict.mu.RUnlock()

	if cp, ok := dict.patterns[name]; ok {
		return cp, true
	}
	return nil, false
}

func (dict *patternDict) Names() []string {
	return dict.keys()
}

func (dict *patternDict) Patterns() []wrkfls.Pattern {
	dict.mu.RLock()
	defer dict.mu.RUnlock()
	var patterns []wrkfls.Pattern
	for _, v := range dict.patterns {
		patterns = append(patterns, v)
	}
	return patterns
}

func (dict *patternDict) NewPattern(name string, regex string, args []rune, params []string) (wrkfls.Pattern, error) {
	cp, err := newPattern(name, regex, args, params)
	if err != nil {
		return nil, err
	}
	dict.add(&cp)
	return &cp, nil
}

func (dict *patternDict) GetPattern(name string) (wrkfls.Pattern, bool) {
	return dict.get(name)
}

func NewPatternDict() *patternDict {
	return &patternDict{patterns: make(map[string]*constraintPattern)}
}

// Singleton pattern

// var (
// 	patterns PatternDict
// 	once     sync.Once
// )

// func singletonPatterns() PatternDict {
// 	once.Do(func() {
// 		patterns = NewPatternDict()
// 	})
// 	return patterns
// }
