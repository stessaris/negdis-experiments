package constraints_test

import (
	"fmt"
	"strings"
	"testing"
	"unicode"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints"
)

func stringToActivities(trace string) []wrkfls.Activity {
	activities := make([]wrkfls.Activity, 0)
	for _, c := range trace {
		if unicode.IsLetter(c) {
			activities = append(activities, wrkfls.Activity(c-'A'+1))
		}
	}
	return activities
}

func simpleConstraint(pattern string, args ...rune) (wrkfls.Constraint, error) {
	pDict := constraints.NewPatternDict()
	err := constraints.ReadTextPatterns(strings.NewReader(pattern), pDict)
	if err != nil {
		return nil, err
	}
	cp := pDict.Patterns()[0]
	c, err := cp.NewConstraint(stringToActivities(string(args)), []int{})
	if err != nil {
		return nil, err
	}
	return c, nil
}

func printPattern(pattern string) (string, error) {
	pDict := constraints.NewPatternDict()
	err := constraints.ReadTextPatterns(strings.NewReader(pattern), pDict)
	if err != nil {
		return "", err
	}
	cp := pDict.Patterns()[0]
	return fmt.Sprint(cp), nil
}

func checkPattern(pattern string, args []rune, trace string) (sat bool, invSat bool, err error) {
	var c wrkfls.Constraint
	c, err = simpleConstraint(pattern, args...)
	if err != nil {
		return
	}
	sTrace := stringToActivities(trace)
	sat, err = c.Check(sTrace)
	if err != nil {
		return
	}
	if len(args) == 2 {
		invSat, err = c.InvCheck(sTrace)
		if err != nil {
			return
		}
	}
	return
}

func verifyPattern(pattern string, args []rune, traces []string) (bool, error) {
	c, err := simpleConstraint(pattern, args...)
	if err != nil {
		return false, err
	}
	for _, strTrace := range traces {
		if sat, err := c.Check(stringToActivities(strTrace)); err != nil {
			return false, err
		} else if !sat {
			return false, nil
		}
	}
	return true, nil
}

func Test_verifyPattern(t *testing.T) {
	type args struct {
		pattern string
		args    []rune
		traces  []string
	}
	tests := []struct {
		name    string
		args    args
		want    bool
		wantErr bool
	}{
		{
			name: "test_Participation(a)",
			args: args{
				pattern: `Participation(a):[^a]*(a[^a]*)+[^a]*`,
				args:    []rune{'a'},
				traces: []string{
					"bcaac",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_Uniqueness(a)",
			args: args{
				pattern: `Uniqueness(a):[^a]*(a)?[^a]*`,
				args:    []rune{'a'},
				traces: []string{
					"bcac",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_Init(a)",
			args: args{
				pattern: `Init(a):a.*`,
				args:    []rune{'a'},
				traces: []string{
					"accbbbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_End(a)",
			args: args{
				pattern: `End(a):.*a`,
				args:    []rune{'a'},
				traces: []string{
					"bcaaccbbbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_RespondedExistence(a, b)",
			args: args{
				pattern: `RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaaccbbbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_Response(a, b)",
			args: args{
				pattern: `Response(a, b):[^a]*(a.*b)*[^a]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaaccbbbab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_AlternateResponse(a, b)",
			args: args{
				pattern: `AlternateResponse(a, b):[^a]*(a[^a]*b)*[^a]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaccbbbab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_wrong_ChainResponse(a, b)",
			args: args{
				pattern: `wrong_ChainResponse(a, b):[^a]*(ab[^ab]*)*[^a]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcabbbab",
				},
			},
			want: false, wantErr: false,
		},
		{
			name: "test_ChainResponse(a, b)",
			args: args{
				pattern: `ChainResponse(a, b):[^a]*(ab[^a]*)*[^a]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcabbbab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_Precedence(a, b)",
			args: args{
				pattern: `Precedence(a, b):[^b]*(a.*b)*[^b]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"caaccbbbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_AlternatePrecedence(a, b)",
			args: args{
				pattern: `AlternatePrecedence(a, b):[^b]*(a[^b]*b)*[^b]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"caaccbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_ChainPrecedence(a, b)",
			args: args{
				pattern: `ChainPrecedence(a, b):[^b]*(ab[^ab]*)*[^b]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"cababa",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_CoExistence(a, b)",
			args: args{
				pattern: `CoExistence(a, b):[^ab]*((a.*b)|(b.*a))*[^ab]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaccbbbaba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_Succession(a, b)",
			args: args{
				pattern: `Succession(a, b):[^ab]*(a.*b)*[^ab]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"caaccbbbab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_AlternateSuccession(a, b)",
			args: args{
				pattern: `AlternateSuccession(a, b):[^ab]*(a[^ab]*b)*[^ab]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"caccbab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_ChainSuccession(a, b)",
			args: args{
				pattern: `ChainSuccession(a, b):[^ab]*(ab[^ab]*)*[^ab]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"cabab",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_wrong_NotChainSuccession(a, b)",
			args: args{
				pattern: `wrong_NotChainSuccession(a, b):[^a]*(a[^ab][^a]*)*([^a]*|a)`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaaccbbbba",
				},
			},
			want: false, wantErr: false,
		},
		{
			name: "test_NotChainSuccession(a, b)",
			args: args{
				pattern: `NotChainSuccession(a, b):[^a]*(a[^b][^a]*)*([^a]*|a)`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaaccbbbba",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_NotSuccession(a, b)",
			args: args{
				pattern: `NotSuccession(a, b):[^a]*(a[^b]*)*[^ab]*`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"bcaacca",
				},
			},
			want: true, wantErr: false,
		},
		{
			name: "test_NotCoExistence(a, b)",
			args: args{
				pattern: `NotCoExistence(a, b):[^ab]*((a[^b]*)|(b[^a]*))?`,
				args:    []rune{'a', 'b'},
				traces: []string{
					"caacca",
				},
			},
			want: true, wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := verifyPattern(tt.args.pattern, tt.args.args, tt.args.traces)
			if (err != nil) != tt.wantErr {
				t.Errorf("verifyPattern() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("verifyPattern() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_printPattern(t *testing.T) {
	type args struct {
		pattern string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "t1",
			args: args{
				pattern: `RespondedExistence(x, y):[^x]*((x.*y)|(y.*x))*[^x]*`,
			},
			want:    "RespondedExistence(a,b):[^a]*((a.*b)|(b.*a))*[^a]*",
			wantErr: false,
		},
		{
			name: "t2",
			args: args{
				pattern: `Absence[i](x):[^x]*(x[^x]*){0,i}+[^x]*`,
			},
			want:    "Absence[m](a):[^a]*(a[^a]*){0,m}+[^a]*",
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := printPattern(tt.args.pattern)
			if (err != nil) != tt.wantErr {
				t.Errorf("printPattern() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("printPattern() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_checkPattern(t *testing.T) {
	type args struct {
		pattern string
		args    []rune
		trace   string
	}
	tests := []struct {
		name       string
		args       args
		wantSat    bool
		wantInvSat bool
		wantErr    bool
	}{
		{"cp_1", args{`Response(a, b):[^a]*(a.*b)*[^a]*`, []rune{'x', 'y'}, `xzzywwww`}, true, false, false},
		{"cp_2", args{`Response(a, b):[^a]*(a.*b)*[^a]*`, []rune{'y', 'x'}, `xzzywwww`}, false, true, false},
		{"cp_3", args{`RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*`, []rune{'x', 'y'}, `ywxxwwyyyxyx`}, true, true, false},
		{"cp_4", args{`Precedence(a,b):[^b]*(a.*b)*[^b]*`, []rune{'x', 'z'}, `xzy`}, true, false, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotSat, gotInvSat, err := checkPattern(tt.args.pattern, tt.args.args, tt.args.trace)
			if (err != nil) != tt.wantErr {
				t.Errorf("checkPattern() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if gotSat != tt.wantSat {
				t.Errorf("checkPattern() gotSat = %v, want %v", gotSat, tt.wantSat)
			}
			if gotInvSat != tt.wantInvSat {
				t.Errorf("checkPattern() gotInvSat = %v, want %v", gotInvSat, tt.wantInvSat)
			}
		})
	}
}
