package constraints

import (
	"reflect"
	"testing"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func TestCompressTrace(t *testing.T) {
	type args struct {
		trace       []wrkfls.Activity
		activityMap map[wrkfls.Activity]rune
	}
	tests := []struct {
		name string
		args args
		want []rune
	}{
		{
			name: "CompressTrace_1",
			args: args{[]wrkfls.Activity{4, 3, 10, 11, 2, 4}, map[wrkfls.Activity]rune{10: 'a', 3: 'b'}},
			want: []rune{'_', 'b', 'a', '_'},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CompressTrace(tt.args.trace, tt.args.activityMap); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("CompressTrace() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_normaliseRegexp(t *testing.T) {
	type args struct {
		regex    string
		argNames []rune
		parNames []string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "t1",
			args: args{
				regex:    `[^x]*(x[^x]*){r,}+[^x]*`,
				argNames: []rune{'x'},
				parNames: []string{"r"},
			},
			want: "[^a]*(a[^a]*){m,}+[^a]*",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := normaliseRegexp(tt.args.regex, tt.args.argNames, tt.args.parNames); got != tt.want {
				t.Errorf("normaliseRegexp() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_renameArgs(t *testing.T) {
	type args struct {
		regex string
		repl  map[rune]rune
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "t1",
			args: args{
				regex: `[^x]*(x[^x]*){r,}+[^x]*`,
				repl:  map[rune]rune{'x': 'a'},
			},
			want: "[^a]*(a[^a]*){r,}+[^a]*",
		},
		{`t2`, args{`[^b]*(a.*b)*[^b]*`, map[rune]rune{'a': 'b', 'b': 'a'}}, `[^a]*(b.*a)*[^a]*`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := renameArgs(tt.args.regex, tt.args.repl); got != tt.want {
				t.Errorf("renameArgs() = %v, want %v", got, tt.want)
			}
		})
	}
}
