package ctraces

import (
	"fmt"
	"regexp"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type compressedLogExt struct {
	logs              []string
	cLogs             map[string]bool
	activitiesMapping map[wrkfls.Activity]rune
}

func CompressLog(log wrkfls.Log, activities ...wrkfls.Activity) wrkfls.CompressedLog {
	cLog := &compressedLogExt{
		logs:              make([]string, log.Size()),
		cLogs:             make(map[string]bool),
		activitiesMapping: make(map[wrkfls.Activity]rune),
	}

	for i, a := range activities {
		cLog.activitiesMapping[a] = rune(i + 'a')
	}

	i := 0
	for logIt := log.Iterator(); logIt.Next(); {
		cLog.logs[i] = string(compress(logIt.Trace(), cLog.activitiesMapping, true))
		cLog.cLogs[cLog.logs[i]] = true
		i++
	}

	return cLog
}

func compress(trace []wrkfls.Activity, mapping map[wrkfls.Activity]rune, zip bool) []rune {
	capacity := len(trace)
	if zip {
		capacity = capacity / 3
	}
	ct := make([]rune, 0, capacity)
	for _, a := range trace {
		if r, ok := mapping[a]; ok {
			ct = append(ct, r)
		} else if !zip || len(ct) < 1 || ct[len(ct)-1] != '_' {
			ct = append(ct, '_')
		}
	}

	return ct
}

func (cLog compressedLogExt) regexp(c wrkfls.Constraint) (*regexp.Regexp, error) {
	ptrnArgs := make([]rune, len(c.Args()))
	for i, a := range c.Args() {
		if v, ok := cLog.activitiesMapping[a]; ok {
			ptrnArgs[i] = v
		} else {
			return nil, fmt.Errorf("Activity %v missing in compressed log", a)
		}
	}

	return c.Pattern().Regex(ptrnArgs, c.Parameters())
}

func (cLog compressedLogExt) Satisfies(c wrkfls.Constraint) (bool, error) {
	rexp, err := cLog.regexp(c)
	if err != nil {
		return false, err
	}

	for cTrace := range cLog.cLogs {
		matches := rexp.MatchString(cTrace)
		logging.Debug().Str("constraint", fmt.Sprintf("%v", c)).Str("regexp", rexp.String()).Str("trace", cTrace).Bool("result", matches).Msg("matching compressed trace")
		if !matches {
			return false, nil
		}
	}

	return true, nil
}

func (cLog compressedLogExt) Check(c wrkfls.Constraint) ([]bool, error) {
	rexp, err := cLog.regexp(c)
	if err != nil {
		return nil, err
	}

	satTraces := make(map[string]bool)
	for cTrace := range cLog.cLogs {
		matches := rexp.MatchString(cTrace)
		logging.Debug().Str("constraint", fmt.Sprintf("%v", c)).Str("regexp", rexp.String()).Str("trace", cTrace).Bool("result", matches).Msg("matching compressed trace")
		if matches {
			satTraces[cTrace] = true
		}
	}

	results := make([]bool, len(cLog.logs))
	for i, t := range cLog.logs {
		_, results[i] = satTraces[t]
	}

	return results, nil
}

func (cLog compressedLogExt) SatisfiesInverse(c wrkfls.Constraint) (bool, error) {
	return false, fmt.Errorf("method not implemented")
}
