package traces

import (
	"io"
	"reflect"
	"strings"
	"testing"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func TestReadCSVInt(t *testing.T) {
	type args struct {
		in          io.Reader
		activityMap wrkfls.ActivityNames
	}
	tests := []struct {
		name    string
		args    args
		want    traceLog
		wantErr bool
	}{
		{
			name: "TestReadInt_1",
			args: args{strings.NewReader(`10, 3, 12, 1`), NewActivityNames()},
			want: traceLog{
				{10, 3, 12, 1},
			},
			wantErr: false,
		},
		{
			name: "TestReadInt_2",
			args: args{strings.NewReader(`
			10, 3, 12, 1
			3`), NewActivityNames()},
			want: traceLog{
				{10, 3, 12, 1},
				{3},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readCSVInt(tt.args.in, tt.args.activityMap)
			if (err != nil) != tt.wantErr {
				t.Errorf("ReadInt() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ReadInt() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestReadCSVLog(t *testing.T) {
	type args struct {
		in          io.Reader
		activityMap wrkfls.ActivityNames
	}
	tests := []struct {
		name    string
		args    args
		want    traceLog
		wantErr bool
	}{
		{
			name: "TestReadLog_1",
			args: args{
				in: strings.NewReader(`
				this, is, a, log, log
				is`),
				activityMap: NewActivityNames(),
			},
			want: traceLog{
				{1, 2, 3, 4, 4},
				{2},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readCSVLog(tt.args.in, tt.args.activityMap)
			if (err != nil) != tt.wantErr {
				t.Errorf("ReadLog() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ReadLog() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestReadTextLog(t *testing.T) {
	type args struct {
		in          io.Reader
		activityMap wrkfls.ActivityNames
	}
	tests := []struct {
		name    string
		args    args
		want    traceLog
		wantErr bool
	}{
		{
			name: "ReadTextLog_1",
			args: args{
				in: strings.NewReader(`
				bcaac
				cababa
				`),
				activityMap: NewActivityNames(),
			},
			want: traceLog{
				{1, 2, 3, 3, 2}, {2, 3, 1, 3, 1, 3},
			}, wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := readTextLog(tt.args.in, tt.args.activityMap)
			if (err != nil) != tt.wantErr {
				t.Errorf("ReadTextLog() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ReadTextLog() = %v, want %v", got, tt.want)
			}
		})
	}
}
