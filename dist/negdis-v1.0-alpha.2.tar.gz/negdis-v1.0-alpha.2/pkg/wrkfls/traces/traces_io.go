package traces

import (
	"bufio"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"strconv"
	"strings"
	"unicode"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type logReader func(in io.Reader, activityMap wrkfls.ActivityNames) (wrkfls.Log, error)

var (
	logFormats map[string]logReader = map[string]logReader{
		"csv":  readCSVLog,
		"text": readTextLog,
	}
	defaultLogReaderFormat string = "text"
)

func LogFormats() []string {
	formats := make([]string, 0, len(logFormats))
	formats = append(formats, defaultLogReaderFormat)
	for k := range logFormats {
		if k != formats[0] {
			formats = append(formats, k)
		}
	}
	return formats
}

func getLogReader(format string) (logReader, error) {
	if reader, ok := logFormats[format]; ok {
		return reader, nil
	} else {
		return nil, fmt.Errorf("log parser for format %v not available", format)
	}
}

func ReadLog(in io.Reader, fmt string, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	reader, err := getLogReader(fmt)
	if err != nil {
		return nil, err
	}
	return reader(in, activityMap)
}

func readCSVInt(in io.Reader, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	var logTrace traceLog
	r := csv.NewReader(in)
	r.FieldsPerRecord = -1

	for {
		record, err := r.Read()
		if err == io.EOF {
			break
		} else if err != nil {
			return traceLog{}, err
		}
		var tr []wrkfls.Activity
		for _, as := range record {
			if a, err := strconv.Atoi(strings.TrimSpace(as)); err != nil {
				log.Printf("'%v' is not a valid action (integer). Skipping it", as)
			} else {
				tr = append(tr, wrkfls.Activity(a))
			}
		}
		if len(tr) > 0 {
			logTrace = append(logTrace, tr)
		}
	}
	return logTrace, nil
}

func readCSVLog(in io.Reader, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	var logTrace traceLog

	r := csv.NewReader(in)
	r.FieldsPerRecord = -1

	for {
		record, err := r.Read()
		if err == io.EOF {
			break
		} else if err != nil {
			return traceLog{}, err
		}
		var tr []wrkfls.Activity
		for _, as := range record {
			a := activityMap.Add(strings.TrimSpace(as))
			tr = append(tr, a)
		}
		if len(tr) > 0 {
			logTrace = append(logTrace, tr)
		}
	}

	return logTrace, nil
}

func readTextLog(in io.Reader, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	var logTrace traceLog

	scanner := bufio.NewScanner(in)
	for scanner.Scan() {
		var tr []wrkfls.Activity
		for _, c := range scanner.Text() {
			if unicode.IsLetter(c) || unicode.IsSymbol(c) {
				a := activityMap.Add(string(c))
				tr = append(tr, a)
			}
		}
		if err := scanner.Err(); err != nil {
			return nil, err
		}
		if len(tr) > 0 {
			logTrace = append(logTrace, tr)
		}
	}

	return logTrace, nil
}

func WriteJSON(out io.Writer, log wrkfls.Log, activityMap wrkfls.ActivityNames) error {

	enc := json.NewEncoder(out)
	// enc.SetIndent("", "  ")
	jsonLog := make(map[string]interface{})
	jsonLog["log"] = log
	if activityMap.Size() > 0 {
		jsonLog["names"] = activityMap.Names()
	}

	return enc.Encode(jsonLog)
}
