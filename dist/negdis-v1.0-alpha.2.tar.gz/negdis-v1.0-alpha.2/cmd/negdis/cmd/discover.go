package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/discover"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

var discoverCmd = &cobra.Command{
	Use:   "discover",
	Short: "Workflow discover algorithms",
}

func init() {
	rootCmd.AddCommand(discoverCmd)

	discoverCmd.AddCommand(compDiscoverCmd())
	discoverCmd.AddCommand(negDiscoverCmd())
}

func compDiscoverCmd() *cobra.Command {
	newCmd := &cobra.Command{
		Use:   "compatible [<log>]",
		Short: "Reports the list of constraints compatible with all the given log. If the argument is not provided, or is '-', the log is read from stdin.",
		Args:  cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			out := getCmdOutput(cmd)
			activityMap := traces.NewActivityNames()

			lPath := "-"
			if len(args) > 0 {
				lPath = args[0]
			}
			log, err := getLogFromPath(cmd, lPath, "fmt", activityMap)
			if err != nil {
				return err
			}
			patternBase, err := getFlagTemplate(cmd, "templ")
			if err != nil {
				return err
			}

			return discover.WriteCompatibleConstraints(out, log, patternBase, activityMap)
		},
	}

	logFormats := traces.LogFormats()
	newCmd.Flags().StringP("fmt", "f", logFormats[0], fmt.Sprintf("format of the logs, one of %v", logFormats))
	newCmd.Flags().StringP("templ", "t", "-", "file path with the templates, - for stdin")

	return newCmd
}

func negDiscoverCmd() *cobra.Command {
	newCmd := &cobra.Command{
		Use:   "negative <positive traces> <negative traces>",
		Short: "Reports the constraints that invalidate the negative log",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) error {
			out := getCmdOutput(cmd)
			activityMap := traces.NewActivityNames()
			posLog, err := getLogFromPath(cmd, args[0], "fmt", activityMap)
			if err != nil {
				return err
			}
			negLog, err := getLogFromPath(cmd, args[1], "fmt", activityMap)
			if err != nil {
				return err
			}
			patternBase, err := getFlagTemplate(cmd, "templ")
			if err != nil {
				return err
			}

			return discover.WriteUnsatChoices(out, posLog, negLog, patternBase, activityMap)
		},
	}

	logFormats := traces.LogFormats()
	newCmd.Flags().StringP("fmt", "f", logFormats[0], fmt.Sprintf("format of the logs, one of %v", logFormats))
	newCmd.Flags().StringP("templ", "t", "-", "file path with the templates, - for stdin")

	return newCmd
}
