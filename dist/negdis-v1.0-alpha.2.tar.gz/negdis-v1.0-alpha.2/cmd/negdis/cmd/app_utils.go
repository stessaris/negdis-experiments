package cmd

import (
	"fmt"
	"io"
	"os"
	"reflect"
	"strings"

	"github.com/spf13/cobra"
	"github.com/spf13/pflag"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints/declare"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

func getLogFromFlag(cmd *cobra.Command, fileOpt string, fmtOpt string, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	path, err := cmd.Flags().GetString(fileOpt)
	if err != nil {
		return nil, err
	}
	return getLogFromPath(cmd, path, fmtOpt, activityMap)
}

func getLogFromPath(cmd *cobra.Command, path string, fmtOpt string, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	format, err := cmd.Flags().GetString(fmtOpt)
	if err != nil {
		return nil, err
	}

	var in io.Reader
	if strings.TrimSpace(path) == "-" {
		in = os.Stdin
	} else {
		fd, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer fd.Close()
		in = fd
	}

	return traces.ReadLog(in, format, activityMap)
}

func getFlagTemplate(cmd *cobra.Command, fileOpt string) (wrkfls.PatternDict, error) {
	path, err := cmd.Flags().GetString(fileOpt)
	if err != nil {
		return nil, err
	}
	if cmd.Flags().Changed(fileOpt) {
		return getPathTemplate(cmd, path)
	} else {
		return declare.PatternBase(), nil
	}
}

func getPathTemplate(cmd *cobra.Command, path string) (wrkfls.PatternDict, error) {
	patternBase := constraints.NewPatternDict()
	var in io.Reader

	if strings.TrimSpace(path) == "-" {
		in = os.Stdin
	} else {
		fd, err := os.Open(path)
		if err != nil {
			return patternBase, err
		}
		defer fd.Close()
		in = fd
	}

	err := constraints.ReadTextPatterns(in, patternBase)
	return patternBase, err
}

func getConstraintsFromPath(cmd *cobra.Command, path string, patternBase wrkfls.PatternDict, activityNames wrkfls.ActivityNames) ([]wrkfls.Constraint, error) {
	var in io.Reader
	if strings.TrimSpace(path) == "-" {
		in = os.Stdin
	} else {
		fd, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer fd.Close()
		in = fd
	}

	return constraints.ReadConstraints(in, patternBase, activityNames)
}

func getConstraintsFromFlag(cmd *cobra.Command, fileOpt string, patternBase wrkfls.PatternDict, activityNames wrkfls.ActivityNames) ([]wrkfls.Constraint, error) {
	path, err := cmd.Flags().GetString(fileOpt)
	if err != nil {
		return nil, err
	}
	return getConstraintsFromPath(cmd, path, patternBase, activityNames)
}

func addPersistentPreRun(cmd *cobra.Command, pre func(cmd *cobra.Command, args []string)) {
	if reflect.ValueOf(cmd.PersistentPreRun).IsZero() {
		cmd.PersistentPreRun = pre
	} else {
		oldPre := cmd.PersistentPreRun
		cmd.PersistentPreRun = func(cmd *cobra.Command, args []string) {
			oldPre(cmd, args)
			pre(cmd, args)
		}
	}
}

func addPersistentPostRun(cmd *cobra.Command, post func(cmd *cobra.Command, args []string)) {
	if reflect.ValueOf(cmd.PersistentPostRun).IsZero() {
		cmd.PersistentPostRun = post
	} else {
		oldPost := cmd.PersistentPreRun
		cmd.PersistentPostRun = func(cmd *cobra.Command, args []string) {
			oldPost(cmd, args)
			post(cmd, args)
		}
	}
}

func printArguments(cmd *cobra.Command, args []string) {
	fmt.Fprintf(cmd.OutOrStderr(), "Command: %v\n", cmd.Name())
	cmd.Flags().Visit(func(f *pflag.Flag) {
		fmt.Fprintf(cmd.OutOrStderr(), "  flag %v: '%v'\n", f.Name, f.Value)
	})
	if len(args) > 0 {
		fmt.Fprintf(cmd.OutOrStderr(), "  Args: ['%v']\n", strings.Join(args, "', '"))
	} else {
		fmt.Fprintln(cmd.OutOrStderr(), "  Args: []")
	}
}

func outStreamFromFlag(cmd *cobra.Command, flagName string) (*os.File, error) {
	if cmd.Flags().Changed(flagName) {
		fname, err := cmd.Flags().GetString(flagName)
		if err != nil {
			return nil, err
		}
		fd, err := os.OpenFile(fname, os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			return nil, err
		}
		return fd, nil
	}
	return nil, nil
}
