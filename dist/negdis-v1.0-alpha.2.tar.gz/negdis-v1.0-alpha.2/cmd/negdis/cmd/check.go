package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/discover"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

func init() {
	checkCmd := &cobra.Command{
		Use:   "check",
		Short: "Check constraints and traces satisfiability",
	}
	checkCmd.AddCommand(checkConstraintsCmd())

	rootCmd.AddCommand(checkCmd)
}

func checkConstraintsCmd() *cobra.Command {
	newCmd := &cobra.Command{
		Use:   "constraints <log file> [<constraints file>]",
		Short: "For each trace in the log reports the compatible constraints. If not provided, constraints are read from stdin",
		Args:  cobra.RangeArgs(1, 2),
		RunE: func(cmd *cobra.Command, args []string) error {
			out := getCmdOutput(cmd)
			activityMap := traces.NewActivityNames()
			log, err := getLogFromPath(cmd, args[0], "fmt", activityMap)
			if err != nil {
				return err
			}
			patternBase, err := getFlagTemplate(cmd, "templ")
			if err != nil {
				return err
			}
			cPath := "-"
			if len(args) > 1 {
				cPath = args[1]
			}

			constraints, err := getConstraintsFromPath(cmd, cPath, patternBase, activityMap)
			if err != nil {
				return err
			}

			return discover.CheckConstraints(out, log, constraints, activityMap)
		},
	}

	logFormats := traces.LogFormats()
	newCmd.Flags().StringP("fmt", "f", logFormats[0], fmt.Sprintf("format of the logs, one of %v", logFormats))
	newCmd.Flags().StringP("templ", "t", "-", "file path with the templates, - for stdin")

	return newCmd
}
