package cmd

import (
	"fmt"

	"github.com/spf13/cobra"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/traces"
)

var showCmd = &cobra.Command{
	Use:   "show",
	Short: "Display information about internal data",
}

func init() {
	rootCmd.AddCommand(showCmd)
	showCmd.AddCommand(showLogCmd())
	showCmd.AddCommand(showPatternsCmd())
}

func showLogCmd() *cobra.Command {
	newCmd := &cobra.Command{
		Use:   "log [<log>]",
		Short: "read a log and outputs its internal representation in JSON",
		Args:  cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			out := getCmdOutput(cmd)
			activityMap := traces.NewActivityNames()
			lPath := "-"
			if len(args) > 0 {
				lPath = args[0]
			}
			log, err := getLogFromPath(cmd, lPath, "fmt", activityMap)
			if err != nil {
				return err
			}

			return traces.WriteJSON(out, log, activityMap)
		},
	}

	logFormats := traces.LogFormats()
	newCmd.Flags().StringP("fmt", "f", logFormats[0], fmt.Sprintf("format of the logs, one of %v", logFormats))

	return newCmd
}

func showPatternsCmd() *cobra.Command {
	newCmd := &cobra.Command{
		Use:   "templates",
		Short: "outputs the constraint templates in use",
		RunE: func(cmd *cobra.Command, args []string) error {
			out := getCmdOutput(cmd)
			patternBase, err := getFlagTemplate(cmd, "templ")
			if err != nil {
				return err
			}
			for _, p := range patternBase.Patterns() {
				fmt.Fprintln(out, p)
			}
			return nil
		},
	}
	newCmd.Flags().StringP("templ", "t", "-", "file path with the templates, - for stdin")
	return newCmd
}
