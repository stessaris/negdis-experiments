package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
	"github.com/spf13/viper"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/version"
)

const Version = "1.0-alpha.2"

var rootCmd = &cobra.Command{
	Use:   "negdis",
	Short: "Negative traces model discovery",
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func init() {
	rootCmd.AddCommand(
		&cobra.Command{
			Use:   "version",
			Short: "print the version information of the application",
			Run: func(cmd *cobra.Command, args []string) {
				gitVersion := ""
				if len(version.GitVersion) > 0 {
					gitVersion = "(" + version.GitVersion + ")"
				}
				fmt.Fprintf(cmd.OutOrStdout(), "%v application version %v %v\n", cmd.Root().Name(), Version, gitVersion)
			},
		},
	)

	// log level flag
	rootCmd.PersistentFlags().Bool("debug", false, "set debug mode")
	rootCmd.PersistentFlags().String("logfile", "", "write logging to file")
	addPersistentPreRun(rootCmd, setLogLevel)
	addPersistentPostRun(rootCmd, closeLog)

	rootCmd.PersistentFlags().Bool("timestamps", false, "honor timestamps on logs")
	_ = viper.BindPFlag("xes.timestamps", rootCmd.PersistentFlags().Lookup("timestamps"))
}

var logFile *os.File

func setLogLevel(cmd *cobra.Command, args []string) {
	fd, err := outStreamFromFlag(cmd, "logfile")
	if err != nil {
		logging.Fatal().Err(err).Msg("cannot open logfile")
	} else if fd != nil {
		logFile = fd
		logging.SetOutput(logFile)
	}
	if debug, _ := cmd.Flags().GetBool("debug"); debug {
		logging.ActivateDebug()
	}
}

func closeLog(cmd *cobra.Command, args []string) {
	if logFile != nil {
		if err := logFile.Close(); err != nil {
			logging.Fatal().Err(err).Msg("cannot open logfile")
		}
	}
}
