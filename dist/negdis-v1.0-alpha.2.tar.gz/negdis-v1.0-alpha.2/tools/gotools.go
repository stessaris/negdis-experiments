// +build gotools

package gotools

import (
	_ "github.com/goreleaser/goreleaser"
)
