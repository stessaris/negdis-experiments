#!/usr/bin/env python

import argparse
import io
import json
import logging
from pathlib import Path
from subprocess import Popen, run, check_output
import shlex
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from typing import Any, Callable, Dict, Sequence, Set, TextIO, Tuple, Union


CURRENT_DIR = Path(__file__).parent.resolve()
SPEC_DIR = Path() # default to current directory

VERSION = check_output(['git', 'describe', '--always', '--dirty'], text=True).strip()
MAIN_GO = CURRENT_DIR.joinpath('..', 'cmd', 'negdis', 'main.go').resolve()

NEGDIS_CMD = ['go', 'run', '-trimpath', '-ldflags', f"-X gitlab.inf.unibz.it/wrkflw/negdis/internal/version.GitVersion={VERSION}", MAIN_GO]


def read_spec(fd: TextIO) -> Union[Dict, Sequence]:
    try:
        import yaml
        return yaml.safe_load(fd)
    except ImportError:
        pass
    cmd = []
    if shutil.which('yq'):
        cmd = shlex.split('yq -o json e')
    elif shutil.which('ruby'):
        cmd = shlex.split("ruby -rjson -ryaml -e 'print JSON.dump(YAML.load(ARGF.read()))'")
    if len(cmd) > 0:
        return json.loads(check_output(cmd, stdin=fd))
    else:
        # crossing fingers and hope for JSON input
        return json.load(fd)


def run_spec(spec: Dict[str, Any], negdis: Sequence[str] = None, debug: bool = False, out: TextIO = None) -> int:
    if out is None:
        out = sys.stdout

    with TemporaryDirectory() as tmpdir:
        def write_to_file(key: str) -> Path:
            path = Path(tmpdir).joinpath(f'{key}.txt')
            content = str(spec[key])
            with path.open('w') as fd:
                fd.write(str(content))
            return path

        files: Dict[str, Path] = {key: SPEC_DIR.joinpath(value) for key, value in spec.get('files', dict()).items()}
        for key in ('templates', 'positive', 'negative', 'constraints'):
            if key in spec:
                files[key] = write_to_file(key)
        flags = spec.get('flags', dict())
        negdis_subcommads = spec.get('cmd', ['help'])
        negdis_exec = negdis if negdis else spec.get('negdis', NEGDIS_CMD)

        cmd = negdis_exec + flags.get('global', [])
        if debug:
            cmd.append('--debug')
        cmd += negdis_subcommads + flags.get('cmd', [])

        filter_func: Callable[[TextIO], None] = None
        if negdis_subcommads == ['check', 'constraints']:
            if 'templates' in files:
                cmd += ['--templ', files['templates']]
            cmd += [files['positive'], files['constraints']]
        elif negdis_subcommads == ['discover', 'negative']:
            if 'templates' in files:
                cmd += ['--templ', files['templates']]
            cmd += [files['positive'], files['negative']]
            filter_func = choices_filter
        elif negdis_subcommads == ['discover', 'compatible']:
            if 'templates' in files:
                cmd += ['--templ', files['templates']]
            cmd += [files['positive']]
        elif negdis_subcommads[0] not in ('help', 'version'):
            logging.warning(f'Unsupported command {negdis_subcommads}')
            cmd = negdis_exec + ['help']

        logging.info('Running: [' + ' '.join(shlex.quote(str(a)) for a in cmd) + '] -> ' + out.name)

        if filter_func:
            cp = Popen(cmd, stdout=subprocess.PIPE)
            filter_func(io.TextIOWrapper(cp.stdout), out)
        else:
            cp = run(cmd, stdout=out)
        return cp.returncode


def choices_filter(fd: TextIO, out: TextIO = sys.stdout):
    trace_choices = json.load(fd)
    for trace_info in trace_choices:
        trace_info['choices'] = sorted(trace_info.get('choices', []))
    json.dump(trace_choices, out, ensure_ascii=False)


def diff_choices(choices_fd_a: TextIO, choices_fd_b: TextIO, out: TextIO):
    def read_choices(fd: TextIO) -> Dict[Tuple, Set[str]]:
        all_choices = dict()
        for trace_choices in json.load(fd):
            trace = tuple(trace_choices.get('trace', []))
            if trace in all_choices:
                continue
            all_choices[trace] = set(trace_choices.get('choices', []))
        return all_choices

    choices_a = read_choices(choices_fd_a)
    choices_b = read_choices(choices_fd_b)

    all_traces = set(choices_a.keys())
    all_traces.update(choices_b.keys())

    diff_data = dict()

    for trace in all_traces:
        ca = choices_a.get(trace, set())
        cb = choices_b.get(trace, set())

        diff_data[trace] = ['+' + c for c in cb.difference(ca)] + ['-' + c for c in ca.difference(cb)]

    for trace, diff in diff_data.items():
        if len(diff) > 0:
            print(f'{trace}: {sorted(diff)}', file=out)


def diff_spec(spec: Dict[str, Any], old_negdis: Sequence[str], negdis: Sequence[str] = None, debug: bool = False, out: TextIO = None) -> int:
    if out is None:
        out = sys.stdout
    with TemporaryDirectory() as tmpdir:
        old_out_path = Path(tmpdir).joinpath('old_output')
        new_out_path = Path(tmpdir).joinpath('new_output')

        with old_out_path.open('w') as fd:
            run_spec(spec, negdis=old_negdis, debug=debug, out=fd)
        with new_out_path.open('w') as fd:
            run_spec(spec, negdis=negdis, debug=debug, out=fd)

        negdis_subcommads = spec.get('cmd', ['help'])
        diff_func: Callable[[TextIO, TextIO, TextIO], None] = None
        if negdis_subcommads == ['discover', 'negative']:
            diff_func = diff_choices

        if diff_func:
            with old_out_path.open() as old_fd, new_out_path.open() as new_fd:
                diff_func(old_fd, new_fd, out)
            return_status = 0
        else:
            cmd = ['diff', old_out_path, new_out_path]
            logging.info('Running: [' + ' '.join(shlex.quote(str(a)) for a in cmd) + '] -> ' + out.name)
            cp = run(cmd, stdout=out)
            return_status = cp.returncode

    return return_status

def main(command_args: Sequence[str]) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('spec', type=argparse.FileType(), default=sys.stdin, help='Execution spec JSON file')
    parser.add_argument('--debug', action='store_true', help='enables debugging')
    parser.add_argument('--negdis', help='use a specific negdis command')
    parser.add_argument('--out', type=argparse.FileType('w'), help='write output to the file')
    parser.add_argument('--diff', help='compare results with given negdis')
    args = parser.parse_args(command_args)

    logging.getLogger().setLevel(logging.DEBUG if args.debug else logging.INFO)

    negdis_exec = shlex.split(args.negdis) if args.negdis else None
    spec_path = Path(args.spec.name)
    specs = read_spec(args.spec)
    if spec_path.exists():
        global SPEC_DIR
        SPEC_DIR = spec_path.parent.absolute()
    if isinstance(specs, Dict):
        specs = [specs]

    if args.diff:
        codes = [diff_spec(spec, shlex.split(args.diff), negdis=negdis_exec, debug=args.debug, out=args.out) for spec in specs]
    else:
        codes = [run_spec(spec, negdis=negdis_exec, debug=args.debug, out=args.out) for spec in specs]

    try:
        return next(c for c in codes if c != 0)
    except StopIteration:
        return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))