#!/usr/bin/env python

"""Takes in input a JSON file as produced by `negdis discover negative`:

    [ {choices: [<constraint>, ...], trace: [<event>, ...]}, ... ]

and for each constraint counts the number of traces for which it's a choice.
"""

import sys
import json
from operator import itemgetter
from typing import Dict


def count_choice(fp) -> Dict[str, int]:
    trace_choices = json.load(fp)
    c_count = {}
    for tc in trace_choices:
        for c in tc.get('choices', []):
            c_count[c] = c_count.get(c, 0) + 1
    return c_count


def main(*args) -> int:
    if len(args) > 1:
        with open(args[1]) as fp:
            c_count = count_choice(fp)
    else:
        c_count = count_choice(sys.stdin)

    for k, v in sorted(c_count.items(), key=itemgetter(1), reverse=True):
        print('{}: {}'.format(k, v))

    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv))