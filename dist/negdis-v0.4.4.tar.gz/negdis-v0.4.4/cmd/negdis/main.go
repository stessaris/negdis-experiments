package main

import (
	"gitlab.inf.unibz.it/wrkflw/negdis/cmd/negdis/cmd"
)

func main() {
	cmd.Execute()
}
