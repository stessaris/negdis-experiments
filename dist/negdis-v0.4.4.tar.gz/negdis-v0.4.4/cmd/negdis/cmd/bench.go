package cmd

import (
	"github.com/spf13/cobra"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/bench"
)

var benchCmd = &cobra.Command{
	Use:   "bench",
	Short: "Run model discovery benchmarks",
}

var randomLogCmd = &cobra.Command{
	Use:   "random",
	Short: "Run discovery of compatible constraints on a random log",
	RunE:  randomBench,
}

func init() {
	rootCmd.AddCommand(benchCmd)

	benchCmd.AddCommand(randomLogCmd)
	randomLogCmd.Flags().Int("act", 10, "Number of activities to use")
	randomLogCmd.Flags().Int("size", 20, "Number of traces in the log")
	randomLogCmd.Flags().Int("average", 20, "Average size of traces")
	randomLogCmd.Flags().Int("stddev", 3, "Standard deviation for the lenght of generated traces")
}

func randomBench(cmd *cobra.Command, args []string) error {

	out := getCmdOutput(cmd)
	maxActivity, err := cmd.Flags().GetInt("act")
	if err != nil {
		return err
	}
	logSize, err := cmd.Flags().GetInt("size")
	if err != nil {
		return err
	}
	averageTrace, err := cmd.Flags().GetInt("average")
	if err != nil {
		return err
	}
	stdDevTrace, err := cmd.Flags().GetInt("stddev")
	if err != nil {
		return err
	}

	return bench.RandomLog(out, maxActivity, logSize, averageTrace, stdDevTrace)
}
