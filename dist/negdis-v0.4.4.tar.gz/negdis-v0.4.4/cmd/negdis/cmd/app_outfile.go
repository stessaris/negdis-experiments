package cmd

import (
	"io"
	"os"

	"github.com/spf13/cobra"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
)

var outputFile *os.File

const outputFileFlag = "out"

func initOutFile(cmd *cobra.Command, args []string) {
	fd, err := outStreamFromFlag(cmd, outputFileFlag)
	if err != nil {
		logging.Fatal().Err(err).Msg("cannot open output file")
	} else if fd != nil {
		outputFile = fd
	}
}

func closeOutFile(cmd *cobra.Command, args []string) {
	if outputFile != nil {
		if err := outputFile.Close(); err != nil {
			panic(err)
		}
	}
}

func getCmdOutput(cmd *cobra.Command) io.Writer {
	if outputFile != nil {
		return outputFile
	}
	return os.Stdout
}

func init() {
	rootCmd.PersistentFlags().String(outputFileFlag, "-", "write output to file path instead of stdout")
	addPersistentPreRun(rootCmd, initOutFile)
	addPersistentPostRun(rootCmd, closeOutFile)
}
