package traces

import (
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints"
)

type traceLog [][]wrkfls.Activity
type compressedLog []string

type logScanner struct {
	idx int
	log traceLog
}

type activityNames struct {
	toAct  map[string]wrkfls.Activity
	toName []string
}

func (actNs *activityNames) Names() []string {
	return actNs.toName
}

func (actNs *activityNames) Size() int {
	return len(actNs.toName)
}

func (actNs *activityNames) Add(name string) wrkfls.Activity {
	if a, ok := actNs.toAct[name]; ok {
		return a
	}
	a := wrkfls.Activity(len(actNs.toAct) + 1)
	actNs.toAct[name] = a
	actNs.toName = append(actNs.toName, name)
	return a
}

func (actNs *activityNames) Get(name string) (wrkfls.Activity, bool) {
	a, ok := actNs.toAct[name]
	return a, ok
}

func (actNs *activityNames) GetName(act wrkfls.Activity) (string, bool) {
	if act < 1 || int(act) > actNs.Size() {
		return "", false
	}
	return actNs.toName[act-1], true
}

func NewActivityNames() wrkfls.ActivityNames {
	return &activityNames{toAct: make(map[string]wrkfls.Activity), toName: []string{}}
}

func (log traceLog) Compress(activities ...wrkfls.Activity) wrkfls.CompressedLog {
	var cLog compressedLog

	mapping := constraints.ActivityMap(activities...)

	for _, tr := range log {
		cLog = append(cLog, string(constraints.CompressTrace(tr, mapping)))
	}

	return cLog
}

func (log traceLog) Size() int {
	return len(log)
}

func (log traceLog) Iterator() wrkfls.LogScanner {
	return &logScanner{-1, log}
}

func (it *logScanner) Next() bool {
	it.idx++
	return it.idx < len(it.log)
}

func (it *logScanner) Trace() []wrkfls.Activity {
	if it.idx < len(it.log) {
		return it.log[it.idx]
	} else {
		return nil
	}
}

func (cLog compressedLog) Satisfies(c wrkfls.Constraint) (bool, error) {

	for _, ct := range cLog {
		if sat, err := c.SCheck(ct); err != nil {
			return sat, err
		} else if !sat {
			return false, nil
		}
	}

	return true, nil
}

func (cLog compressedLog) SatisfiesInverse(c wrkfls.Constraint) (bool, error) {

	for _, ct := range cLog {
		if sat, err := c.SInvCheck(ct); err != nil {
			return sat, err
		} else if !sat {
			return false, nil
		}
	}

	return true, nil
}

func (log traceLog) Satisfies(c wrkfls.Constraint) (bool, error) {
	return log.Compress(c.Args()...).Satisfies(c)
}

func (log traceLog) SatisfiesInverse(c wrkfls.Constraint) (bool, error) {
	return log.Compress(c.Args()...).SatisfiesInverse(c)
}
