package traces

import (
	"encoding/xml"
	"fmt"
	"io"
	"sort"
	"time"

	"github.com/spf13/viper"
	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func init() {
	logFormats["xes"] = readXES
	defaultLogReaderFormat = "xes"

	viper.SetDefault("xes.timestamps", false)
}

type xesEvent struct {
	name      string
	timestamp time.Time
}

func readXES(in io.Reader, activityMap wrkfls.ActivityNames) (wrkfls.Log, error) {
	var logTrace traceLog

	xmlDec := xml.NewDecoder(in)
	var trace []*xesEvent
	var event *xesEvent
	var lastTs time.Time
	var sortTrace bool

	for {
		token, err := xmlDec.Token()
		if err != nil {
			if err == io.EOF {
				break
			} else {
				return logTrace, err
			}
		}

		switch tokenType := token.(type) {
		case xml.EndElement:
			switch tokenType.Name.Local {
			case `log`:
				return logTrace, nil
			case `trace`:
				if len(trace) > 0 {
					if sortTrace && viper.GetBool("xes.timestamps") {
						// trace needs sorting
						logging.Debug().Int("index", len(logTrace)).Msg("sorting XES trace")
						sort.SliceStable(trace, func(i, j int) bool { return trace[i].timestamp.Before(trace[j].timestamp) })
					}
					logTrace = append(logTrace, xesToTrace(trace, activityMap))
				}
			case `event`:
				if event != nil && len(event.name) > 0 {
					if event.timestamp == (time.Time{}) {
						// missing timestamp, invent a new one
						event.timestamp = lastTs.Add(time.Millisecond)
						logging.Warn().Str("event", fmt.Sprint(event)).Msg("adding missing timestamp")
					}
					if lastTs.After(event.timestamp) {
						// trace needs to be sorted!
						sortTrace = true
					}
					lastTs = event.timestamp
					trace = append(trace, event)
				}
				event = nil
			}
		case xml.StartElement:
			switch tokenType.Name.Local {
			case `trace`:
				trace = nil
				lastTs = time.Time{}
				sortTrace = false
			case `event`:
				event = &xesEvent{}
			case `string`:
				if event != nil {
					key, value, _ := xesEventKeyValue(tokenType)
					if key == `concept:name` && len(value) > 0 {
						event.name = value
					}
				}
			case `date`:
				if event != nil {
					key, value, _ := xesEventKeyValue(tokenType)
					if key == `time:timestamp` && len(value) > 0 {
						if t, err := time.Parse("2006-01-02T15:04:05.999-07:00", value); err == nil {
							event.timestamp = t
						} else {
							logging.Warn().Str("value", value).AnErr("error", err).Msg("failed to parse timestamp")
						}
					}
				}
			}

		}
	}

	return logTrace, nil
}

func xesToTrace(xesT []*xesEvent, activityMap wrkfls.ActivityNames) []wrkfls.Activity {
	trace := make([]wrkfls.Activity, len(xesT))
	for i, xe := range xesT {
		a := activityMap.Add(xe.name)
		trace[i] = a
	}
	return trace
}

func xesEventKeyValue(element xml.StartElement) (string, string, error) {
	var key, value string
	for _, attr := range element.Attr {
		switch attr.Name.Local {
		case `key`:
			key = attr.Value
		case `value`:
			value = attr.Value
		}
	}

	if len(key) > 0 {
		return key, value, nil
	} else {
		return key, value, fmt.Errorf("missing key/value attribute pair in %v", element)
	}
}
