package traces

import (
	"math/rand"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func RandomLog(size int, lastAct wrkfls.Activity, meanTrace int, devTrace int) traceLog {
	log := make(traceLog, 0, size)
	for i := 0; i < size; i++ {
		ts := traceSize(meanTrace, devTrace)
		log = append(log, randomTrace(ts, lastAct))
	}
	return log
}

func traceSize(meanTrace int, devTrace int) int {
	return int(rand.NormFloat64()*float64(devTrace) + float64(meanTrace))
}

func randomTrace(size int, lastAct wrkfls.Activity) []wrkfls.Activity {
	trace := make([]wrkfls.Activity, 0, size)
	for i := 0; i < size; i++ {
		trace = append(trace, wrkfls.Activity(rand.Intn(int(lastAct))+1))
	}
	return trace
}
