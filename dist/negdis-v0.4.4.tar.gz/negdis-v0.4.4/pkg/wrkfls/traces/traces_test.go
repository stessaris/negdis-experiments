package traces

import (
	"reflect"
	"testing"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func TestLog_Compress(t *testing.T) {
	type args struct {
		activities []wrkfls.Activity
	}
	tests := []struct {
		name string
		log  traceLog
		args args
		want compressedLog
	}{
		{
			name: "traceCompress_1",
			log:  traceLog{{4, 3, 10, 11, 2, 4}},
			args: args{[]wrkfls.Activity{10, 3}},
			want: compressedLog{"_ba_"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.log.Compress(tt.args.activities...); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Log.Compress() = %v, want %v", got, tt.want)
			}
		})
	}
}
