package constraints

import (
	"fmt"
	"regexp"
	"strings"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

var maxReArgs = 10
var otherAct = '_' // activities not mapped to any char

func argName(i int) rune {
	if i >= maxReArgs {
		panic(fmt.Errorf("At most %v regexp arguments are supported!", maxReArgs))
	}
	return rune(i + 'a')
}

func paramName(i int) rune {
	if i >= maxReArgs {
		panic(fmt.Errorf("At most %v regexp arguments are supported!", maxReArgs))
	}
	return rune(i + 'm')
}

func renameArgs(regex string, repl map[rune]rune) string {
	newRe := ""
	for _, c := range regex {
		if nc, ok := repl[c]; ok {
			newRe += string(nc)
		} else {
			newRe += string(c)
		}
	}
	return newRe
}

func compileRegexp(regex string, parNames []rune, params []int) (*regexp.Regexp, error) {
	if len(parNames) > 0 {
		if len(params) >= len(parNames) {
			for i, p := range parNames {
				regex = strings.ReplaceAll(regex, string(p), string(params[i]))
			}
		} else {
			return nil, fmt.Errorf("missing regexp parameters")
		}
	}
	// anchor regexp to match the whole input
	return regexp.Compile("^(" + regex + ")$")
}

func normaliseRegexp(regex string, argNames []rune, parNames []string) string {
	normRegex := regex

	for i, pname := range parNames {
		normRegex = strings.ReplaceAll(normRegex, pname, string(paramName(i)))
	}

	mapping := make(map[rune]rune)
	for i, aname := range argNames {
		mapping[aname] = argName(i)
	}
	return renameArgs(normRegex, mapping)
}

func CompressTrace(trace []wrkfls.Activity, activityMap map[wrkfls.Activity]rune) []rune {

	var ct []rune
	var lastR rune

	for _, a := range trace {
		if c, ok := activityMap[a]; ok {
			ct = append(ct, c)
			lastR = c
		} else if lastR != otherAct {
			ct = append(ct, otherAct)
			lastR = otherAct
		}
	}

	return ct
}

func ActivityMap(activities ...wrkfls.Activity) map[wrkfls.Activity]rune {
	mapping := make(map[wrkfls.Activity]rune)
	for i, a := range activities {
		mapping[a] = argName(i)
	}
	return mapping
}
