package declare

import (
	"fmt"
	"strings"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls/constraints"
)

const (
	declarePatternsDefCIDM2013 = `
		Absence[m](a):[^a]*(a[^a]*){0,m}+[^a]*
		AlternatePrecedence(a, b):[^b]*(a[^b]*b)*[^b]*
		AlternateResponse(a, b):[^a]*(a[^a]*b)*[^a]*
		AlternateSuccession(a, b):[^ab]*(a[^ab]*b)*[^ab]*
		ChainPrecedence(a, b):[^b]*(ab[^ab]*)*[^b]*
		ChainResponse(a, b):[^a]*(ab[^a]*)*[^a]*
		ChainSuccession(a, b):[^ab]*(ab[^ab]*)*[^ab]*
		CoExistence(a, b):[^ab]*((a.*b)|(b.*a))*[^ab]*
		End(a):.*a
		Existence[n](a):[^a]*(a[^a]*){n,}+[^a]*
		Init(a):a.*
		NotChainSuccession(a, b):[^a]*(a[^b][^a]*)*([^a]*|a)
		NotCoExistence(a, b):[^ab]*((a[^b]*)|(b[^a]*))?
		NotSuccession(a, b):[^a]*(a[^b]*)*[^ab]*
		Participation(a):[^a]*(a[^a]*)+[^a]*
		Precedence(a, b):[^b]*(a.*b)*[^b]*
		RespondedExistence(a, b):[^a]*((a.*b)|(b.*a))*[^a]*
		Response(a, b):[^a]*(a.*b)*[^a]*
		Succession(a, b):[^ab]*(a.*b)*[^ab]*
		Uniqueness(a):[^a]*(a)?[^a]*
	`
	declarePatternsDefIS2017 = `
		AlternatePrecedence(x,y):[^y]*(x[^y]*y[^y]*)*[^y]*
		AlternateResponse(x,y):[^x]*(x[^x]*y[^x]*)*[^x]*
		AlternateSuccession(x,y):[^xy]*(x[^xy]*y[^xy]*)*[^xy]*
		AtMostOne(x):[^x]*(x)?[^x]*
		ChainPrecedence(x,y):[^y]*(xy[^y]*)*[^y]*
		ChainResponse(x,y):[^x]*(xy[^x]*)*[^x]*
		ChainSuccession(x,y):[^xy]*(xy[^xy]*)*[^xy]*
		CoExistence(x,y):[^xy]*((x.*y.*)|(y.*x.*))*[^xy]*
		End(x):.*x
		Init(x):x.*
		NotChainSuccession(x,y):[^x]*(xx*[^xy][^x]*)*([^x]*|x)
		NotCoExistence(x,y):[^xy]*((x[^y]*)|(y[^x]*))?
		NotSuccession(x,y):[^x]*(x[^y]*)*[^xy]*
		Participation(x):[^x]*(x[^x]*)+[^x]*
		Precedence(x,y):[^y]*(x.*y)*[^y]*
		RespondedExistence(x,y):[^x]*((x.*y.*)|(y.*x.*))*[^x]*
		Response(x,y):[^x]*(x.*y)*[^x]*
		Succession(x,y):[^xy]*(x.*y)*[^xy]*
	`
	declarePatternsDef = declarePatternsDefIS2017
)

var (
	declarePatterns wrkfls.PatternDict
)

func init() {
	declarePatterns = constraints.NewPatternDict()
	err := constraints.ReadTextPatterns(strings.NewReader(declarePatternsDef), declarePatterns)
	if err != nil {
		panic(fmt.Errorf("Cannot initialise Declare patterns: %v", err))
	}
}

func PatternBase() wrkfls.PatternDict {
	return declarePatterns
}
