package constraints

import (
	"fmt"
	"io"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/parsing"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func ReadConstraints(in io.Reader, patternBase wrkfls.PatternDict, activityNames wrkfls.ActivityNames) ([]wrkfls.Constraint, error) {

	parsedCs, err := parsing.ParseConstraints(in)
	if err != nil {
		return nil, err
	}

	constraints := make([]wrkfls.Constraint, 0, len(parsedCs))
	for _, pc := range parsedCs {
		ptrn, ok := patternBase.GetPattern(pc.GetName())
		if !ok {
			return nil, fmt.Errorf("missing constraint pattern '%v'", pc.GetName())
		}
		argsS := pc.GetArgs()
		args := make([]wrkfls.Activity, 0, len(argsS))
		for _, an := range argsS {
			args = append(args, activityNames.Add(an))
		}

		nc, err := ptrn.NewConstraint(args, pc.GetParams())
		if err != nil {
			return constraints, err
		}
		constraints = append(constraints, nc)
	}

	return constraints, nil
}
