package constraints

import (
	"fmt"
	"reflect"
	"regexp"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type constraintPattern struct {
	name         string
	argNames     []rune
	parNames     []rune
	regex        string
	compRegex    regexp.Regexp
	swappedRegex regexp.Regexp
}

func (ptrn constraintPattern) Name() string {
	return ptrn.name
}

func (ptrn constraintPattern) Arity() int {
	return len(ptrn.argNames)
}

func (ptrn constraintPattern) ParamArity() int {
	return len(ptrn.parNames)
}

func (ptrn constraintPattern) NewConstraint(args []wrkfls.Activity, params []int) (wrkfls.Constraint, error) {
	if ptrn.Arity() > len(args) {
		return nil, fmt.Errorf("missing arguments for pattern %v, expecting %d received %d", ptrn.Name(), ptrn.Arity(), len(args))
	}
	if ptrn.ParamArity() > len(params) {
		return nil, fmt.Errorf("missing parameters for pattern %v, expecting %d received %d", ptrn.Name(), ptrn.ParamArity(), len(params))
	}
	return &constraint{&ptrn, args[:ptrn.Arity()], params[:ptrn.ParamArity()]}, nil
}

func (ptrn constraintPattern) compiledRegexp(params []int) (*regexp.Regexp, error) {
	if !reflect.ValueOf(ptrn.compRegex).IsZero() {
		if len(params) > 0 {
			panic(fmt.Errorf("inconsistent state for pattern %v", ptrn))
		}
		return &ptrn.compRegex, nil
	} else {
		return compileRegexp(ptrn.regex, ptrn.parNames, params)
	}
}

func (ptrn constraintPattern) compiledInvRegexp(params []int) (*regexp.Regexp, error) {
	if !reflect.ValueOf(ptrn.swappedRegex).IsZero() {
		return &ptrn.swappedRegex, nil
	} else {
		return nil, fmt.Errorf("inverse pattern %v is not compiled", ptrn.name)
	}
}

func (ptrn constraintPattern) sCheck(cTrace string, params ...int) (bool, error) {
	if re, err := ptrn.compiledRegexp(params); err != nil {
		return false, err
	} else {
		matches := re.MatchString(cTrace)
		logging.Debug().Str("pattern", ptrn.String()).Str("regexp", re.String()).Str("trace", cTrace).Bool("result", matches).Msg("matching compressed trace")
		return matches, nil
	}
}

func (ptrn constraintPattern) sInvCheck(cTrace string, params ...int) (bool, error) {
	if re, err := ptrn.compiledInvRegexp(params); err != nil {
		return false, err
	} else {
		matches := re.MatchString(cTrace)
		logging.Debug().Str("pattern", ptrn.String()).Str("regexp", re.String()).Str("trace", cTrace).Bool("result", matches).Msg("inverse matching compressed trace")
		return matches, nil
	}
}

func newPattern(name string, regex string, args []rune, params []string) (constraintPattern, error) {
	nRegex := normaliseRegexp(regex, args, params)
	nArgs := make([]rune, len(args))
	for i := range args {
		nArgs[i] = argName(i)
	}
	nParams := make([]rune, len(params))
	for i := range params {
		nParams[i] = paramName(i)
	}

	cp := constraintPattern{name: name, regex: nRegex, argNames: nArgs, parNames: nParams}
	if len(nParams) < 1 {
		re, err := compileRegexp(cp.regex, cp.parNames, []int{})
		if err != nil {
			return cp, err
		}
		cp.compRegex = *re

		// generate and compile swapped arguments regexp only if it's arity 2
		if len(nArgs) == 2 {
			re, err := compileRegexp(renameArgs(cp.regex, map[rune]rune{nArgs[0]: nArgs[1], nArgs[1]: nArgs[0]}), []rune{}, []int{})
			if err != nil {
				return cp, err
			}
			cp.swappedRegex = *re
		}
	}
	logging.Debug().Str(`pattern`, cp.String()).Str(`regex`, fmt.Sprint(cp.compRegex)).Str(`invRegex`, fmt.Sprint(cp.swappedRegex)).Msg("creating new pattern")
	return cp, nil
}

func (ptrn constraintPattern) String() string {
	s := ptrn.name
	if len(ptrn.parNames) > 0 {
		s += "["
		for i, p := range ptrn.parNames {
			if i > 0 {
				s += ","
			}
			s += string(p)
		}
		s += "]"
	}
	s += "("
	for i, a := range ptrn.argNames {
		if i > 0 {
			s += ","
		}
		s += string(a)
	}
	s += ")"

	s += ":" + ptrn.regex

	return s
}
