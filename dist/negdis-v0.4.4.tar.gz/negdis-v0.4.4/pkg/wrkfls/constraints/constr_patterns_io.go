package constraints

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"regexp"
	"strings"
	"unicode"

	"github.com/rs/zerolog/log"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func parsePatternDef(def string) (string, string, []rune, []string, error) {
	const patternRegexp = `^\s*(\w+)\s*(\[\s*([A-Za-z]+(\s*,\s*[A-Za-z]+)*)*\s*\])?\s*\(\s*([A-Za-z](\s*,\s*[A-Za-z])*)\s*\)\s*:\s*(\S.*\S)\s*$`
	re := regexp.MustCompile(patternRegexp)
	match := re.FindStringSubmatch(def)
	if len(match) < 8 {
		return "", "", nil, nil, fmt.Errorf("wrong pattern definition <%v>", def)
	}
	pName := match[1]
	pRegex := match[7]
	var argNames []rune
	for _, c := range match[5] {
		if unicode.IsLetter(c) {
			argNames = append(argNames, c)
		}
	}
	var paramNames []string
	if len(match[3]) > 0 {
		for _, n := range strings.Split(match[3], ",") {
			paramNames = append(paramNames, strings.TrimSpace(n))
		}
	}

	return pName, pRegex, argNames, paramNames, nil
}

func ReadTextPatterns(in io.Reader, patternsBase wrkfls.PatternDict) error {
	scanner := bufio.NewScanner(in)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if len(line) < 1 {
			continue
		}
		name, regex, argNames, paramNames, err := parsePatternDef(line)
		if err != nil {
			return err
		}
		if _, err := patternsBase.NewPattern(name, regex, argNames, paramNames); err != nil {
			return err
		}
	}
	if err := scanner.Err(); err != nil {
		return err
	}
	return nil
}

func ReadJSONPatterns(in io.Reader, patternsBase wrkfls.PatternDict) error {

	type patternJSON struct {
		Name   string
		Regex  string
		Args   []string
		Params []string
	}

	dec := json.NewDecoder(in)
	for {
		var pl []patternJSON
		if err := dec.Decode(&pl); err == io.EOF {
			break
		} else if err != nil {
			return err
		}
		for _, p := range pl {
			args := []rune{}
			for _, arg := range p.Args {
				for _, a := range arg {
					args = append(args, a)
					break
				}
			}
			if _, err := patternsBase.NewPattern(p.Name, p.Regex, args, p.Params); err != nil {
				log.Info().Str("name", p.Name).AnErr("error", err).Msg("error creating pattern, skipping it")
			}
		}
	}

	return nil
}
