package bench

import (
	"os"
)

func ExampleRandomLog() {
	RandomLog(os.Stdout, 50, 1000, 30, 5)
	// Output:
}
