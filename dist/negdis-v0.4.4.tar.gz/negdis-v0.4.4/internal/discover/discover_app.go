package discover

import (
	"encoding/json"
	"fmt"
	"io"

	"gitlab.inf.unibz.it/wrkflw/negdis/internal/logging"
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func WriteCompatibleConstraints(out io.Writer, log wrkfls.Log, patternsBase wrkfls.PatternDict, activityMap wrkfls.ActivityNames) error {
	lastAct := wrkfls.Activity(activityMap.Size())
	if lastAct < 1 {
		lastAct = lastActivity(log)
	}

	var printer ConstraintsWalker = func(c wrkfls.Constraint) (bool, error) {
		fmt.Fprintln(out, c.ToString(activityMap))
		return true, nil
	}
	_, err := AllSATConstraints(log, patternsBase.Patterns(), lastAct, printer)

	return err
}

func WriteUnsatChoices(out io.Writer, pLog wrkfls.Log, nLog wrkfls.Log,
	patternsBase wrkfls.PatternDict, activityMap wrkfls.ActivityNames) error {
	lastAct := wrkfls.Activity(activityMap.Size())
	if lastAct < 1 {
		lastAct = lastActivity(pLog, nLog)
	}

	constraints, err := CollectAllSATConstraints(pLog, patternsBase.Patterns(), lastAct)
	if err != nil {
		return err
	}
	jsonEnc := json.NewEncoder(out)
	if _, err := io.WriteString(out, "[\n"); err != nil {
		return err
	}
	defer func() {
		if _, err := io.WriteString(out, "]\n"); err != nil {
			logging.Debug().Msg("Cannot write on file")
		}
	}()
	sep := ""
	for it := nLog.Iterator(); it.Next(); {
		trace := it.Trace()
		cs, err := unsatConstraints(constraints, trace)
		if err != nil {
			return err
		}
		if _, err := io.WriteString(out, sep); err != nil {
			return err
		}
		if err := jsonEnc.Encode(map[string][]string{
			"trace":   traceToStrings(trace, activityMap),
			"choices": constraintsToStrings(cs, activityMap)}); err != nil {
			return err
		}
		sep = ",\n"
	}
	return nil
}

func CheckConstraints(out io.Writer, log wrkfls.Log, constraints []wrkfls.Constraint, activityMap wrkfls.ActivityNames) error {
	if logging.IsDebug() {
		logging.Debug().Object("activitymap", logging.ActivityMapLogger(activityMap)).Msg("activity names")
	}
	jsonEnc := json.NewEncoder(out)
	if _, err := io.WriteString(out, "[\n"); err != nil {
		return err
	}
	defer func() {
		if _, err := io.WriteString(out, "]\n"); err != nil {
			logging.Debug().Msg("Cannot write on file")
		}
	}()
	sep := ""
	cStrings := constraintsToStrings(constraints, activityMap)
	satStat := map[string]bool{}
	for it := log.Iterator(); it.Next(); {
		trace := it.Trace()
		for i, c := range constraints {
			sat, err := c.Check(trace)
			if err != nil {
				return err
			}
			satStat[cStrings[i]] = sat
		}
		if _, err := io.WriteString(out, sep); err != nil {
			return err
		}
		if err := jsonEnc.Encode(map[string]interface{}{
			"trace": traceToStrings(trace, activityMap),
			"sat":   satStat}); err != nil {
			return err
		}
		sep = ",\n"
	}
	return nil
}

func traceToStrings(trace []wrkfls.Activity, activityMap wrkfls.ActivityNames) []string {
	mTrace := make([]string, 0, len(trace))

	for _, a := range trace {
		if an, ok := activityMap.GetName(a); !ok {
			mTrace = append(mTrace, string(a))
		} else {
			mTrace = append(mTrace, an)
		}
	}

	return mTrace
}

func constraintsToStrings(constraints []wrkfls.Constraint, activityMap wrkfls.ActivityNames) []string {
	mConstrs := make([]string, 0, len(constraints))
	for _, c := range constraints {
		mConstrs = append(mConstrs, c.ToString(activityMap))
	}
	return mConstrs
}
