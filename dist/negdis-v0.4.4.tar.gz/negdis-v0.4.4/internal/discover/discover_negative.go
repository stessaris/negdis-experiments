package discover

import "gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"

func filterConstraints(constraints []wrkfls.Constraint, filter func(c wrkfls.Constraint) (bool, error)) ([]wrkfls.Constraint, error) {
	cs := make([]wrkfls.Constraint, 0, len(constraints)/2)
	for _, c := range constraints {
		if ok, err := filter(c); err != nil {
			return cs, err
		} else if ok {
			cs = append(cs, c)
		}
	}
	return cs, nil
}

func satConstraints(constraints []wrkfls.Constraint, trace []wrkfls.Activity) ([]wrkfls.Constraint, error) {
	return filterConstraints(
		constraints,
		func(c wrkfls.Constraint) (bool, error) { return c.Check(trace) })
}

func unsatConstraints(constraints []wrkfls.Constraint, trace []wrkfls.Activity) ([]wrkfls.Constraint, error) {
	return filterConstraints(
		constraints,
		func(c wrkfls.Constraint) (bool, error) { sat, err := c.Check(trace); return !sat, err })
}

func UnsatChoices(negativeTraces wrkfls.Log, constraints []wrkfls.Constraint) ([][]wrkfls.Constraint, error) {
	choices := make([][]wrkfls.Constraint, negativeTraces.Size())
	for i, it := 0, negativeTraces.Iterator(); it.Next(); i++ {
		if cs, err := unsatConstraints(constraints, it.Trace()); err != nil {
			return choices, err
		} else {
			choices[i] = cs
		}
	}
	return choices, nil
}
