package discover

import (
	"fmt"
	"io"
	"time"

	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

func ProfileAllSAT(out io.Writer, log wrkfls.Log, patterns []wrkfls.Pattern) error {

	patternArityCount := make([]int, 3)
	for _, p := range patterns {
		if p.Arity() < len(patternArityCount) {
			patternArityCount[p.Arity()]++
		}
	}
	logSize := log.Size()
	var lastAct wrkfls.Activity
	var averageTrace float64
	for it := log.Iterator(); it.Next(); {
		averageTrace += float64(len(it.Trace())) / float64(logSize)
		for _, a := range it.Trace() {
			if a > lastAct {
				lastAct = a
			}
		}
	}

	start := time.Now()
	compConstraints, err := countAllSAT(log, patterns, lastAct)
	runTime := time.Since(start)
	if err != nil {
		return err
	}
	fmt.Fprintln(out, "Patterns:")
	for i, c := range patternArityCount {
		if c > 0 {
			fmt.Fprintf(out, "  arity %d: %d\n", i, c)
		}
	}
	fmt.Fprintln(out, "Log:")
	fmt.Fprintf(out, "  activities:    %v\n", lastAct)
	fmt.Fprintf(out, "  size:          %d\n", logSize)
	fmt.Fprintf(out, "  average trace: %v\n", int(averageTrace))
	fmt.Fprintf(out, "Compatible constraints: %d\n", compConstraints)
	fmt.Fprintf(out, "Running (wall) time: %v\n", runTime)
	return nil
}

func countAllSAT(log wrkfls.Log, patterns []wrkfls.Pattern, lastAct wrkfls.Activity) (int, error) {
	var compConstraints int

	var collector ConstraintsWalker = func(c wrkfls.Constraint) (bool, error) {
		compConstraints++
		return true, nil
	}
	_, err := AllSATConstraints(log, patterns, lastAct, collector)
	return compConstraints, err
}
