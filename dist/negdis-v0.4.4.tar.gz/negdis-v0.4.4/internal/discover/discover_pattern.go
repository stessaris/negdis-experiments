package discover

import (
	"gitlab.inf.unibz.it/wrkflw/negdis/pkg/wrkfls"
)

type ConstraintsWalker func(c wrkfls.Constraint) (bool, error)

func applyAllConstraints(
	walker ConstraintsWalker,
	patterns []wrkfls.Pattern, compressedLog wrkfls.Constrainable,
	args ...wrkfls.Activity) (bool, error) {

	for _, ptrn := range patterns {
		// skip patterns with parameters or arity bigger than available arguments
		if ptrn.ParamArity() > 0 || ptrn.Arity() != len(args) {
			continue
		}
		c, err := ptrn.NewConstraint(args, []int{})
		if err != nil {
			return false, err
		}
		if sat, err := compressedLog.Satisfies(c); err != nil {
			return false, err
		} else if sat {
			if cont, err := walker(c); err != nil {
				return false, err
			} else if !cont {
				return false, nil
			}
		}

		// for binary constraints include also inverses
		if ptrn.Arity() == 2 {
			if sat, err := compressedLog.SatisfiesInverse(c); err != nil {
				return false, err
			} else if sat {
				ic, err := ptrn.NewConstraint([]wrkfls.Activity{args[1], args[0]}, []int{})
				if err != nil {
					return false, err
				}
				if cont, err := walker(ic); err != nil {
					return false, err
				} else if !cont {
					return false, nil
				}
			}
		}
	}

	return true, nil
}

func applyAllPatterns(
	walker ConstraintsWalker,
	log wrkfls.Log, patterns []wrkfls.Pattern,
	firstAct, lastAct wrkfls.Activity) (bool, error) {

	for a := firstAct; a <= lastAct; a++ {
		skipUniC := false
		for b := a + 1; b <= lastAct; b++ {
			cLog := log.Compress(a, b)

			if !skipUniC {
				skipUniC = true
				if ok, err := applyAllConstraints(walker, patterns, cLog, a); err != nil {
					return false, err
				} else if !ok {
					return false, nil
				}
			}
			if ok, err := applyAllConstraints(walker, patterns, cLog, a, b); err != nil {
				return false, err
			} else if !ok {
				return false, nil
			}
		}
	}
	// unary constraints on lastAct are not checked because the inner loop didn't run
	if ok, err := applyAllConstraints(walker, patterns, log.Compress(lastAct), lastAct); err != nil {
		return false, err
	} else if !ok {
		return false, nil
	}

	return true, nil
}

func AllSATConstraints(
	log wrkfls.Log, patterns []wrkfls.Pattern, lastAct wrkfls.Activity,
	walker ConstraintsWalker) (bool, error) {

	return applyAllPatterns(walker, log, patterns, wrkfls.Activity(1), lastAct)
}

func CollectAllSATConstraints(log wrkfls.Log, patterns []wrkfls.Pattern, lastAct wrkfls.Activity) ([]wrkfls.Constraint, error) {
	var constraints []wrkfls.Constraint

	var collector ConstraintsWalker = func(c wrkfls.Constraint) (bool, error) {
		constraints = append(constraints, c)
		return true, nil
	}
	_, err := AllSATConstraints(log, patterns, lastAct, collector)

	return constraints, err
}

func lastActivity(logs ...wrkfls.Log) wrkfls.Activity {
	var lastAct wrkfls.Activity
	for _, log := range logs {
		for it := log.Iterator(); it.Next(); {
			for _, a := range it.Trace() {
				if a > lastAct {
					lastAct = a
				}
			}
		}
	}

	return lastAct
}
